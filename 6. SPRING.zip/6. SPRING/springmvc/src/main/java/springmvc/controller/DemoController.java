package springmvc.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DemoController {

	/*@RequestMapping("/home")
	public String home(Model model) {
		model.addAttribute("name","nisha");
		List<String> names=new ArrayList<String>();
		
		names.add("nisha");
		names.add("devikar");
		model.addAttribute("yash",names);
		return "index1";
	}
	
	@RequestMapping("/home1")
	public String home1() {
		
		return "index";
	}
	
	@RequestMapping("/add")
	public ModelAndView check(HttpServletRequest request,HttpServletResponse response)
	{

	//int i=Integer.parseInt(request.getParameter("t1"));
	//int j=Integer.parseInt(request.getParameter("t2"));
	//int k=i+j;
	ModelAndView mv=new ModelAndView();
	mv.setViewName("display");//jsp
	mv.addObject("result","i am nisha");
	return mv;
	}*/
	// ...//(@RequestParam("email") String emailid, Model model)
	/*@RequestMapping("/request")
	public String request()
	{
		return "request";
	}
	@RequestMapping(path="/request",method=RequestMethod.POST)
	
	
	  
	public String handlerequest(@ModelAttribute("employee") Employee employee, Model model)          
	{
	System.out.println(employee);
	model.addAttribute("employee", employee);
	return "show";
	}*/
	
	@RequestMapping("/date")
	public ModelAndView date()
	{

		LocalDateTime date = LocalDateTime.now();

		ModelAndView mav = new ModelAndView();
		
		mav.addObject("date",date);
		mav.setViewName("date");
	
		return mav;
	}

}
