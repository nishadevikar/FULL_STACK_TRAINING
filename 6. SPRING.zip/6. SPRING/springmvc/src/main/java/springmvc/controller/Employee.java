package springmvc.controller;

//import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class Employee {
	private String name;
	private String email;
	private String contact;
	//@DateTimeFormat(pattern = "MM/dd/yyyy")
	//private Date birthday;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	
	
	

}
