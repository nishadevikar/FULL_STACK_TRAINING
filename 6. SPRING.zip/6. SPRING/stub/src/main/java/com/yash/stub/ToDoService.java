package com.yash.stub;

import java.util.List;

public interface ToDoService {
	public List<String> retrieveTodos(String user);

}
