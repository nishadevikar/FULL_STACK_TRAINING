package com.yash.stub;

import java.util.ArrayList;
import java.util.List;

public class ToDoBuissnessImpl {
	private ToDoService todoService;
	
	ToDoBuissnessImpl(ToDoService todoService) {
		this.todoService = todoService;
	}
	
	public List<String> retrieveTodosRelatedSpring(String user) {
		List<String> filteredTodos = new ArrayList<String>();
		List<String> allTodos = new ArrayList<String>();
		
	}

}
