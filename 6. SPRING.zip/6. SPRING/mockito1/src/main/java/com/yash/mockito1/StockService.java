package com.yash.mockito1;

public interface StockService {
	public double getPrice(Stock stock);

}
