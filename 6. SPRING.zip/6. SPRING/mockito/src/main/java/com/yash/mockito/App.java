package com.yash.mockito;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class App 
	extends TestCase 
{
	public App( String testName ) 
	{
		super(testName);
	}
	
	public static Test Suite() 
	{
		return new TestSuite( App.class );
	}
	
	public void testApp() {
		assertTrue(true);
	}
	
 
}
