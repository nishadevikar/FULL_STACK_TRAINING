package com.howtodoinjava.app.controller;

public class LoggerFactory {

}
