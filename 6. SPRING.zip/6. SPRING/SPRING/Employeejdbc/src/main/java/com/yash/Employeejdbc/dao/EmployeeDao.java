package com.yash.Employeejdbc.dao;

import com.yash.Employeejdbc.entities.Employee;

public interface EmployeeDao {
	public int insert(Employee emp);

}
