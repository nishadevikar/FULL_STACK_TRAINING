package com.yash.springjdbc.dao;

import com.yash.springjdbc.entities.Employee;

public interface EmployeeDao {

	public int insert(Employee stu);
	//public int updatedetails(Employee stu);
//	public int deletedetails(int empid);

	

}