package com.yash.springjdbc.entities;

public class Employee {
	private String empname;
	private int empid;
	private String dob;
	private String contactno;
	private int salary;

	@Override
	public String toString() {
		return "Employee [empname=" + empname + ", empid=" + empid + ", dob=" + dob + ", contactno=" + contactno
				+ ", salary=" + salary + "]";
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

}