package com.yash.springjdbc.dao;

import com.yash.springjdbc.entities.*;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDaoImpl implements EmployeeDao {

	private JdbcTemplate jdbctemp;

	public int insert(Employee stu) {

		String q = "insert into Employee(empname,empid,dob,contactno,salary) values(?,?,?,?,?)";
		int msg = this.jdbctemp.update(q, stu.getEmpname(), stu.getEmpid(),stu.getDob(),stu.getContactno(),stu.getSalary());
		return msg;
	}
//	public int updatedetails(Student stu) {
//		// update details of student
//		String q="update student set name=? where id=?";
//		int msg=this.jdbctemp.update(q,stu.getName(),stu.getId());
//
//		return msg;
//		}
//	public int deletedetails(int stuid) {
//		// TODO Auto-generated method stub
//		String q="delete from student where id=?";
//		int msg=this.jdbctemp.update(q,stuid);
//
//		return msg;
//
//		}

	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}

	public int updatedetails(Employee stu) {
		// TODO Auto-generated method stub
		return 0;
	}

}