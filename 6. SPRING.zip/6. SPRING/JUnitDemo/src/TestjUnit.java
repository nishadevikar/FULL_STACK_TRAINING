import static org.junit.Assert.assertEquals;	//to compare the msg, if same msg then true, otherwise it will trigger a failure
import org.junit.Ignore;
import org.junit.Test;

public class TestjUnit {
	String msg = "Welcome to J-Unit";

	@Test
	public void test() {
		System.out.println("Inside the test()");
		assertEquals(msg, "Welcome to J-Unit");
	}
	public static void main(String[] args) {
		TestjUnit result = new TestjUnit();
		result.test();

	}

}
