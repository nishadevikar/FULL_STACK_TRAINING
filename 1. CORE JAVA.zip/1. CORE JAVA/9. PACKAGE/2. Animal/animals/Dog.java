package animals;
public class Dog implements Animal{
	public void move(){
		System.out.println("Dog moves");
	}
	
	public void eat(){
		System.out.println("Dog eats");
	}
	
	public void sleep(){
		System.out.println("Dog is sleeping");
	}
}