import animals.Animal;
import animals.Kangaroo;
import animals.Dog;
class Cont{
	public static void main(String[] args){
		Kangaroo k = new Kangaroo();
		k.eat();
		k.move();
		k.sleep();
		
		Dog d = new Dog();
		d.eat();
		d.move();
		d.sleep();
	}
}