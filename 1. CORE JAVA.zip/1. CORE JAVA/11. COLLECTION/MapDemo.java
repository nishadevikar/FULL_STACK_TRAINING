import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.*;
class MapDemo
{
	public static void main(String[] args)
	{
		Map map=new HashMap();
		map.put(10, "yash");
		map.put(11, "Technologies");
		map.put(20, "Nisha");
		Set s=map.entrySet();
		Iterator i=s.iterator();
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();
			System.out.println("Key:" +entry.getKey()+" Value:"+entry.getValue());
		}
	}
	//Map.Entry(SubInterface) Interface we will get the key and value separately
	
}