import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Iterator;
public class Months {
	public static void main(String[] args) {
		ArrayList<String> a1=new ArrayList<String>();
		a1.add("January");
		a1.add("February");
		a1.add("March");
		a1.add("April");
		a1.add("May");
		a1.add("June");
		a1.add("July");
		a1.add("August");
		a1.add("September");
		a1.add("October");
		a1.add("November");
		a1.add("December");
		Iterator i=a1.iterator();
		while(i.hasNext()) //check if iterator has elemts
		{
			System.out.println(i.next()); //print current and move to the next
		}
		for(String n:a1)
		{
			System.out.println("Calender Months:" +n);
		}
		System.out.println("Get elemt index 1" +a1.get(1)); //get the value at index 1
		a1.set(2, "YEAR");
		for(String n:a1)
		{
			System.out.println("Calendar Months:" + n);
		}
		Collections.sort(a1);
		for(String n:a1)
		{
			System.out.println("Calendar Months:" + n);
		}
		}
	}

		