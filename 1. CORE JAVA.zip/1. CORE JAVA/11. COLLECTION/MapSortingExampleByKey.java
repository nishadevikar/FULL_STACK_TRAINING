// sort Map by key value
import java.util.*;
class MapSortingExampleByKey {

	static Map<String, Integer> map = new HashMap<>();
	public static void sortbykey()
	{
		ArrayList<String> sortedKeys
			= new ArrayList<String>(map.keySet());

		Collections.sort(sortedKeys);

		for (String x : sortedKeys)
			System.out.println("Key = " + x
							+ ", Value = " + map.get(x));
	}
	public static void main(String args[])
	{
		
		map.put("Nisha", 80);
		map.put("Mahesh", 90);
		map.put("Maneesh", 80);
		map.put("Payal", 75);
		map.put("Amit", 40);

		
		sortbykey();
	}
}

/*Key = Amit, Value = 40
Key = Mahesh, Value = 90
Key = Maneesh, Value = 80
Key = Nisha, Value = 80
Key = Payal, Value = 75*/