import java.util.PriorityQueue;
import java.util.Queue;
import java.util.LinkedList;
class QueueDemo

{
	public static void main(String[] args)
	{
		Queue<Integer> pq=new PriorityQueue<Integer>();
		pq.add(200); //queue is full throws an exception
		pq.add(300);   //comparator interface
		pq.add(400); //offer() it not throws an exception
		System.out.println(pq.peek()); //top elements = 200
		System.out.println(pq.poll()); //200
		System.out.println(pq.peek()); //300
		pq.remove();
		System.out.println(pq);
		Queue<Integer> li=new LinkedList<Integer>();
		li.add(1000);
		li.add(2000);
		li.add(3000);
		System.out.println(li.peek()); //top elements = 200
		System.out.println(li.poll()); //200
		System.out.println(li.peek()); //300
		//in remove it is empty it will throw exception but not in poll
		li.poll();

	}
}