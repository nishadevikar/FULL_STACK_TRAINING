import java.util.ArrayList;;  
import java.util.HashSet;
import java.util.ListIterator;

	 public class ArrayListAssignment1
	 {  
	 public static void main(String args[])
	 {  
	  ArrayList<String> list=new ArrayList<String>();//Creating arraylist    
		list.add("January ");//Adding object in arraylist    
		list.add("February ");    
		list.add("March");    
		list.add("April"); 
		list.add("May "); 
		list.add("June"); 
		list.add("July"); 
		list.add("August"); 
		list.add("September");
		list.add("October");
		list.add("November");
		list.add("December");		
		ListIterator l1=list.listIterator();
		l1.next();  
	    System.out.println(list);  

	  }
	}

/*[January , February , March, April, May , June, July, August, September, October, November, December]/*