import java.util.ArrayList;
class ArrayListExample
{
	public static void main(String[] args) 
	{
		ArrayList A=new ArrayList();
		a.add(10);
		a.add("Yash"); //add method
		a.add('j');
	}
	{
		System.out.println("ArrayList:" + a);
	}
}
	