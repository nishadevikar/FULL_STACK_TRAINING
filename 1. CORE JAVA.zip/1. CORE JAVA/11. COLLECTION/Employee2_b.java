
import java.util.HashSet;
import java.util.Iterator;

public class Employee2_b
{

	public static void main(String[] args) 
	{
		HashSet<String> set = new HashSet<>();
		
		set.add("Nisha");
		set.add("Nitika");
		set.add("Karthik");
		set.add("Amit");
		
		Iterator<String> it = set.iterator();
		while (it.hasNext())
			System.out.println(it.next());

	}

}
/*Nitika
Karthik
Amit
Nisha*/