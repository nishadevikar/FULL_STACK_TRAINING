import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.*;
class MapDemo2
{
	public static void main(String[] args)
	{
		Map<Integer,String> map=new HashMap<Integer,String>();
        map.put(10, "yash");
        map.put(11, "Technologies");
		map.put(20, "Nisha");
		for(Map.Entry m:map.entrySet())
		System.out.println("Key:"+m.getKey()+" Value:"+m.getValue());
	}
}

/*Key:20 Value:Nisha
Key:10 Value:yash
Key:11 Value:Technologies*/