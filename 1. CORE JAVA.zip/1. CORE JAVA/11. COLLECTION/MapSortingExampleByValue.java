// sort Map by value
import java.util.*;
class MapSortingExampleByValue {

	static Map<Integer, String> map = new HashMap<>();
	public static void sortbyValue()
	{
		ArrayList<Integer> sortedValues
			= new ArrayList<Integer>(map.ValueSet());

		Collections.sort(sortedValues);

		for (Integer x : sortedValues)
			System.out.println("Value = " + x
							+ ", Key = " + map.get(x));
	}
	public static void main(String args[])
	{
		
		map.put(30, "Nisha");
		map.put(60, "Maneesha");
		

		
		sortbyValue();
	}
}

