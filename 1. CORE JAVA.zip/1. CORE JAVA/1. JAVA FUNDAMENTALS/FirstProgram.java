package mypackage;
class FirstProgram1
{
    public static void main(String[] args)
	{
	system.out.println("Welcome to YASH Technologies");
	}
}