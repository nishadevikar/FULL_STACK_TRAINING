class LargestNumber
{
    public static void main(String[] args)
	{
	    int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		
		if(a>b)
		{
			System.out.println("a is Large");
		}
			
		else
		{
	
			System.out.println("b is Large");
		}
	}
}

//OUTPUT
//C:\Users\Nisha.devikar\Desktop>javac LargestNumber.java
//C:\Users\Nisha.devikar\Desktop>java LargestNumber 20 30
//b is Large


	