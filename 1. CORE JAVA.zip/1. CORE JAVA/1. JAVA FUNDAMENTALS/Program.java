class FirstProgram
{
    public static void main(string[] args())
	{
	    Systm.out.println("welcome to YASH Technologies");
	}
}