class CommandLineExample{  
public static void main(String args[]){  
System.out.println("Your first argument is: "+args[0]);  
}  
}  

OUTPUT
C:\Users\Nisha.devikar\Desktop>javac CommandLineExample.java
C:\Users\Nisha.devikar\Desktop>java CommandLineExample Man
Your first argument is: Man
