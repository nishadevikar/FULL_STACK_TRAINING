//break
public class BreakExample {  
  
public static void main(String[] args) {  
// TODO Auto-generated method stub  
for(int i = 0; i<= 10; i++) {  
System.out.println(i);  
if(i==6) {  
break;  
}  
}  
}  
}  
/*C:\Users\Nisha.devikar\Desktop>java BreakExample
0
1
2
3
4
5
6*/