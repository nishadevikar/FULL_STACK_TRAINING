//if-else-if statement
class Student1
{
	public static void main(String[] args)
	{
		String city = "Nagpur";
		if(city == "Delhi")
		{
			System.out.println("city is Delhi");//false
		}
		else if(city == "Agra")
		{
		System.out.println("city is Agra");//false
		}
		else
		{
			System.out.println(city);
		}
	}
}
/*C:\Users\Nisha.devikar\Desktop>javac Student1.java
C:\Users\Nisha.devikar\Desktop>java Student1
Nagpur*/		
