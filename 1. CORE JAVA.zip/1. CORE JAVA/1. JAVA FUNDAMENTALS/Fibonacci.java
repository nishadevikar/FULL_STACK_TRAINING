class Fibonacci
{
	public static void main(String[] args)
	{
	int n=10,f1=0,s1=1;
	System.out.println("Fibonacci series till"+n+"term:");
	for (int i=1;i<=n;++i)
	{
		System.out.print(f1+",");
		int nextTerm=f1+s1;
		f1=s1;
		s1=nextTerm;
	}
	}
}
/*C:\Users\Nisha.devikar\Desktop>java Fibonacci
Fibonacci series till10term:
0,1,1,2,3,5,8,13,21,34,*/