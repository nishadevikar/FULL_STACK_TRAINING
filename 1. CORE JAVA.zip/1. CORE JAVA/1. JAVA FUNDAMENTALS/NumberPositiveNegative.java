class NumberPositiveNegative
{
    public static void main(String[] args)
	
 {
    int a=Integer.parseInt(args[0]);
if(a>0)
  
  {
  System.out.println("Number is Positive");
  }
else if(a<0)
{
  System.out.println("Number is Negative");
 }
  else
  {
  System.out.println("Number is Zero");
  }
 }
} 
//C:\Users\Nisha.devikar\Desktop>java NumberPositiveNegative
//C:\Users\Nisha.devikar\Desktop>java NumberPositiveNegative 40
//Number is Positive
