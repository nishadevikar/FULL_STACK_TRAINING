class SwapNo
{
        public static void main(String[] args)
		{
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		int c;
		c=a;
		a=b;
		b=c;
		System.out.println("a and b are:" +a+b);
		}
}
		
