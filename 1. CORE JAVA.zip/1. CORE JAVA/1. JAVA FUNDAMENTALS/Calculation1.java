//for statement
public class Calculation1 
{    
public static void main(String[] args) {    
// TODO Auto-generated method stub    
String[] names = {"Java","C","C++","Python","JavaScript"};    
System.out.println("Printing the content of the array names:\n");    
for(String name:names) {    
System.out.println(name);    
}    
}    
}    
/*
C:\Users\Nisha.devikar\Desktop>java Calculation1
Printing the content of the array names:

Java
C
C++
Python
JavaScript*/
