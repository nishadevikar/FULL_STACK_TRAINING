//if statement
class Student
{
	public static void main(String[] args)
	{
		int x = 10;
		int y = 20;
		if(x+y > 10)//false - won't print anything
		{
			System.out.println("x+y is less than 10");// false condition
		}
		else 
		{
			
			System.out.println("x+y is greater than 10"); //if statement if the condition is true
		}
	}
}
/*C:\Users\Nisha.devikar\Desktop>javac Student.java
C:\Users\Nisha.devikar\Desktop>java Student
x+y is greater than 10*/
