class Switchcalc
{
        public static void main(String[] args)
		{
		double num1, num2;
		char operator;
		    num1=Double.parseDouble(args[0]);
		    num2=Double.parseDouble(args[1]);
			
		operator=args[2].charAt(0);
			
		double output;
		
		switch(operator)
		{
		    case '+':
			    output = num1+num2;
				break;
			
			case '-':
			output = num1-num2;
				break;
				
			case '*':
			output = num1*num2;
				break;
				
		    case '/':
			output = num1/num2;
				break;
	    }
		}
}



			    
