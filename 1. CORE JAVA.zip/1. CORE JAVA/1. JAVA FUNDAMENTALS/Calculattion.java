//loop statement
public class Calculattion 
{  
public static void main(String[] args) 
{   
int sum = 0;  
for(int j = 1; j<=10; j++) 
{  
sum = sum + j;  
}  
System.out.println("The sum of first 10 natural numbers is " + sum);  
}  
}  
/*C:\Users\Nisha.devikar\Desktop>javac Calculattion.java
C:\Users\Nisha.devikar\Desktop>java Calculattion
The sum of first 10 natural numbers is 55*/