public class Calculation2 {    
public static void main(String[] args) {    
// TODO Auto-generated method stub    
int i = 0;    
System.out.println("Printing the list of first 10 even numbers \n");    
while(i<=10) {    
System.out.println(i);    
i = i + 2;    
}    
}    
} 
/*
C:\Users\Nisha.devikar\Desktop>java Calculation2
Printing the list of first 10 even numbers

0
2
4
6
8
10*/   