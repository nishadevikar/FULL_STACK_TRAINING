import java.sql.*;
import java.io.*;
class InsertDemo
{
	public static void main(String[] args) 
	{
		try
		{
		
		//load the driver
		   Class.forName("com.mysql.jdbc.Driver");
		   
		
		    String url="jdbc:mysql://localhost:3306/nisha";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			//creating the query
			String q="insert into employee(empID,name) values(?,?)";
			PreparedStatement ps=con.prepareStatement(q);
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter EmpID:");
			int id=Integer.parseInt(br.readLine());
			System.out.println("Enter EmpName:");
			String name=br.readLine();
			//setting the values
			ps.setInt(1,id);
			ps.setString(2,name);
			ps.executeUpdate();
			System.out.println("Inserted Successfully");
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

		
