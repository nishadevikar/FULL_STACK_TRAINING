
import java.sql.*;
import java.io.*;
class UpdateDemo
{
public static void main(String[] args)
{
try
{
//load the driver
Class.forName("com.mysql.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/nisha";
String user="root";
String pass="root";
Connection con=DriverManager.getConnection(url,user,pass);
//creating the query
String q="update employee set empName=? where empId=?";
PreparedStatement ps = con.prepareStatement(q);
//setting the values
ps.setInt(2,1002);
ps.setString(1,"piyush");
ps.executeUpdate();
System.out.println("Updated Successfully");
con.close();
}
catch(Exception e)
{
e.printStackTrace();
}
}
}

