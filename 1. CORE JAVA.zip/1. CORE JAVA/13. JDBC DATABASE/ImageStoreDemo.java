import java.sql.*;
import java.io.*;
class ImageStoreDemo
{
	public static void main(String[] args)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/nisha";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url, user, pass);
			PreparedStatement ps=con.prepareStatement("insert into yash values(?,?)");
			ps.setString(1, "flower");
			
			FileInputStream f=new FileInputStream("d:\\flower.jfif");
			ps.setBinaryStream(2,f,f.available());
			int i=ps.executeUpdate();
			System.out.println("updated");
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}