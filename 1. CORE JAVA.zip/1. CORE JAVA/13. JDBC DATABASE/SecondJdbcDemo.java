import java.sql.*;
class SecondJdbcDemo{
        public static void main(String args[]){
		try{
		{
		//load the driver
		   Class.forName("com.mysql.jdbc.Driver");
		   
		}
		String url="jdbc:mysql://localhost:3306/nisha";
		String user="root";
		String pass="root";
		Connection con=DriverManager.getConnection(url,user,pass);
		if(con!=null){
		System.out.println("Connection is created successfully !");
		}
		else
		{
		System.out.println("Connection is not created !!!");
		}
		PreparedStatement s = con.prepareStatement("insert into employee2 values(?,?,?)");
				s.setInt(1,103);
				s.setString(2,"swati");
				s.setString(3,"indore");
			int i = s.executeUpdate();
			System.out.println(i+" inserted data");
		   
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}