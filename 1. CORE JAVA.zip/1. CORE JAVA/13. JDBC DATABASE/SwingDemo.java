import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.JLabel;
class SwingDemo
{
   public static void main(String args[])
   {
       JFrame f=new JFrame();
	   JButton b=new JButton("click me");
	   b.setBounds(120,90,90,30);
	   f.add(b);
	   f.setSize(300,400);
	   f.setVisible(true);
	 
	    JPanel p = new JPanel();
		p.add(b);
		
		JLabel l = new JLabel("nothing entered");
		p.add(l);
		 String week[]= { "Monday","Tuesday","Wednesday",
                         "Thursday","Friday","Saturday","Sunday"};
        JList jl= new JList(week);
		f.add(jl);
        
		f.show();
		
		
		
   }
}