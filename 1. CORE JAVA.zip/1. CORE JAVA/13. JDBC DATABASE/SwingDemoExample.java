import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JCheckBox;

class SwingDemoExample{
	
	public static void main(String[] args){
		// Creating main frame
				//Jframe f = f.setDefaultCloseOperation(Jframe.EXIT_ON_CLOSE);

		JFrame mainWindow = new JFrame("Swing Demo");
		mainWindow.setSize(500, 200);
		
		// Creating Panel
		JPanel panel = new JPanel();
		
		// Creating two labels
		JLabel label1 = new JLabel("One: ");
		JLabel label2 = new JLabel("Two: ");
		
		// Adding labels 
		panel.add(label1);
		panel.add(label2);
		
		
		// Creating button 
		JButton button = new JButton();
		button.setText("Click");
		JCheckBox checkBox = new JCheckBox("Check box:");
		
		// Adding both 
		panel.add(checkBox);
		panel.add(button);
		
		// Adding panel to main window
		mainWindow.add(panel);
		
		// Making main window visible
		mainWindow.setVisible(true);
		//Jframe f = f.setDefaultCloseOperation(Jframe.EXIT_ON_CLOSE);
	}
}