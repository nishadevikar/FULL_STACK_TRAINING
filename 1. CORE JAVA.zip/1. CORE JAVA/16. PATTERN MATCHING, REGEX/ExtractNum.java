import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class ExtractNum{
   public static void main(String[] args) {
      String data = "abc12def334hjdsk7438dbds3y388";
      //Regular expression to digits
      String regex = "([0-9]+)";
      //Creating a pattern object
      Pattern pattern = Pattern.compile(regex);
      //Creating a Matcher object
      Matcher matcher = pattern.matcher(data);
      System.out.println("Digits in the given string are: ");
      while(matcher.find()) {
         System.out.print(matcher.group()+" ");
      }
   }
}