import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExtractSubString {

  public static void main(String args[]) {
    Pattern pat = Pattern.compile("\\b\\w+@XYZ\\.com\\b");

    Matcher mat = pat.matcher("t@XYZ.com\n" + "a@XYZ.com\n"
        + "n@XYZ.com");

    while (mat.find())
      System.out.println("Match: " + mat.group());
  }
}