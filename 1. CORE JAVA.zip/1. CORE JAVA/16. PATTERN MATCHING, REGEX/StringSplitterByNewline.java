import java.util.Arrays;
public class StringSplitterByNewline{
 
    public static void main(String args[]){
        String input = "This is a simple String\r\n\n\nLet’s try to split this\nOne more line";
        String[] linesArr = input.split("[\\r?\\n|\\r]+");
        System.out.println(Arrays.toString(linesArr));
    }
}