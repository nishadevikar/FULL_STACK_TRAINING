import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternMatching {
  public static void main(String[] args) {
    Pattern pattern = Pattern.compile("w", Pattern.CASE_INSENSITIVE);
    Matcher matcher = pattern.matcher("Visit W!");
    boolean matchFound = matcher.find();
    if(matchFound) {
      System.out.println("Match found");
    } else {
      System.out.println("Match not found");
    }
  }
}
//C:\Users\Nisha.devikar\Desktop>java PatternMatching
//Match found