class Yash
{
    public static void main(String[] args)
	{
	    String s1=new String("Yash");
	    s1.concat("Tech");
		System.out.println(s1);
		s1=s1.concat("Technologies");
		System.out.println(s1);
	}
}		
		