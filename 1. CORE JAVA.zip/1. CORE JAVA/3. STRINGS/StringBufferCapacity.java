class StringBufferCapacity
{
    public static void main(String[] args)
	{
		StringBuffer sb=new StringBuffer();
		sb.ensureCapacity(50);
		System.out.println(sb.capacity());
		sb.append("Welcome");
		sb.trimToSize();
	    System.out.println(sb.capacity());

		
	}
}