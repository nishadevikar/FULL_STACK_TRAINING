class StringBufferDemo
{
    public static void main(String[] args)
	{
	    /*StringBuffer sb=new StringBuffer("Yash");
		sb.append("Technologies");
		System.out.println(sb);
		String s=new String("Yash");
		s.concat("Technologies");
	    System.out.println(s);*/
		StringBuffer sb=new StringBuffer();
		System.out.println(sb.capacity());
		sb.append("Welcome to Yash Technologies");
		sb.append("Yash");
		System.out.println(sb.capacity());
		//capacity=(old capacity*2)+2;
	    sb.append("Welcome to Yash Technologies");//60
		System.out.println(sb.capacity());
		System.out.println(sb.capacity());
		System.out.println(sb.length()); //(34*2+2)=70
		System.out.println(sb.charAt(4));
		System.out.println(sb.delete(0,6));
		System.out.println(sb);


		

		
		
	}
}

		