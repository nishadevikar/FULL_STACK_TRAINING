class ObjCompariDemo
{
    public static void main(String[] args)
	{
	    String s1=new String("Yash");
		String s2=new String("Yash");
        System.out.println(s1==s2);
		String s3="Nisha";
		String s4="Nisha";
		System.out.println(s3==s4);
		System.out.println(s1.equals(s2));

    }
}		