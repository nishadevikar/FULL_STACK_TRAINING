class StringIsEmpty 
{
  public static void main(String[] args) 
  {
    String sb1 = "Hello";
    String sb2 = "";
    System.out.println(sb1.isEmpty());
    System.out.println(sb2.isEmpty());
  }
}
