class StringTrim 
{    
    public static void main(String[] args) 
	{    
        String s1 = "hello Nisha";    
        System.out.println(s1.length());    
        System.out.println(s1); //Without trim() function    
        String tr = s1.trim();    
        System.out.println(tr.length());    
        System.out.println(tr); //With trim()  function  
    }    
}    