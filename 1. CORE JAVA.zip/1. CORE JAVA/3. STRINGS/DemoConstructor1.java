//how to call a default constructore, this will not have any return type
class DemoConstructor
{
    int i;
	String s;
	public DemoConstructor()
	{
	    System.out.println("Default Constructor");
		}
		public static void main(String[] args)
		{
		    DemoConstructor t=new DemoConstructor();
			System.out.println(t.i);
			System.out.println(t.s);
			}
			}
		
/*C:\Users\Nisha.devikar\Desktop>java DemoConstructor
Default Constructor
0
null/*