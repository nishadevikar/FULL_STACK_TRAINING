class StringBuilderExample
{  
public static void main(String args[])
{  
StringBuilder s1=new StringBuilder("Hello ");  
s1.append("Nisha");//now original string is changed  
System.out.println(s1);//prints Hello Nisha  
}  
} 