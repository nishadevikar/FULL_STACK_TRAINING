class StringEqualsIgnoreCase
{
    public static void main(String[] args)
	{
	String s1 = "HI";
    String s2 = "HI";
    String s3 = "Nisha";
    System.out.println(s1.equalsIgnoreCase(s2)); // true
    System.out.println(s1.equalsIgnoreCase(s3)); // false
	}
}