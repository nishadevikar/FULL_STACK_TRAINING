class CreateString
{
    public static void main(String[] args)
	{
	    String s1="YASH";
		String s2=new String(s1);
	}
    {
		System.out.println(s2);
	}
}