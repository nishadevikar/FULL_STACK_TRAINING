class StringCompare
{
    public static void main(String[] args)
	{
	String s1 = "Hello";
    String s2 = "Nisha";
    System.out.println(s1.compareTo(s2)); // Returns 0 because they are equal
	}
}