class EvenOrNull
{

    public static void main(String[] args) 
	{
	String s1 = args[0];
	
	if(s1.length() % 2 ==0)
	{
	int lastIdx = s1.length()/2;
	for(int i = 0; i < lastIdx; i++)
	{
	System.out.println(s1.charAt(i));
	}
	}
	else
	{
	System.out.println("null");
	}
	}
	}
/*C:\Users\Nisha.devikar\Desktop>java EvenOrNull jaynam
j
a
y/*


	