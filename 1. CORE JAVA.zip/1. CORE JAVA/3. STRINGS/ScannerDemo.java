import java.util.Scanner;

class ScannerDemo
{
        public static void main(String[] args)
		{
		    Scanner input=new Scanner(System.in);
			System.out.print("Enter your name");
			String name=input.nextLine();
			//next()-->reads a word
			                                //nextInt(),neaxtFloat()
			System.out.println("My name is:" + name);
			input.close();
			//Scanner s1=new Scanner(InputStream input);
			//Scanner s2=new Scanner(String s);
		}
}
			