class DemoWithoutThis
{
    int i;//instance variable
	
	void setValue(int i)//local variable
	{
		this.i=i;//15  //this refers to the current class of instancevariable
	}
	void show()
	{
	    System.out.println(i);//instance   //default=0
	}
}
class DemoWithThis
{
        public static void main(String[] args)
		{
		DemoWithoutThis d=new DemoWithoutThis();
		d.setValue(15);
		d.show();
		}
}