class removeFirstLast
{

    public static void main(String[] args) 
	{
	String s1 = args[0];
	
	if(s1.length() < 2)
	{
	System.out.println("String is too small");
	} else {
	for(int i = 1; i < s1.length() - 1; i++)
	{
	System.out.println("null");
	}
	}
	}
	}