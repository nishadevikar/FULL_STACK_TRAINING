//how to call a default constructor, this will not have any return type
class DemoConstructor
{
    int i;
	String s;
	public DemoConstructor()
	{
	    System.out.println("Default Constructor");
		}
		public static void main(String[] args)
		{
		    DemoConstructor t=new DemoConstructor();
			System.out.println(t.i);
			System.out.println(t.s);
			}
			}