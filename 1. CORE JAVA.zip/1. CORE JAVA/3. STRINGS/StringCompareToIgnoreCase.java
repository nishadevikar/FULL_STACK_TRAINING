class StringCompareToIgnoreCase
{
    public static void main(String[] args)
	{
	String p1 = "HELLO";
    String p2 = "hello";
    System.out.println(p1.compareToIgnoreCase(p2));
	}
	
}