class StringIsEqual
{
    public static void main(String[] args)
	{
	String s1 = "Hi";
    String s2 = "Hi";
    String s3 = "My Name is";
    System.out.println(s1.equals(s2)); // Returns true because they are equal
    System.out.println(s1.equals(s3)); // false
	}
}
