class StringBufferPart
{
    public static void main(String[] args)
	{
		StringBuffer sb=new StringBuffer("Welcome to yash Technologies");
		//System.out.println(sb.deleteCharAt(7));
		//StringBuffer sb1=new StringBuffer("Yash");
		//StringBuffer sb2=new StringBuffer("Yash");
		//System.out.println(sb.indexOf("e"));
		//System.out.println(sb.lastIndexOf("e"));
	    //System.out.println(sb.insert(0, "Nisha"));
		//System.out.println(sb.replace(0,6,"Nish"));
		//System.out.println(sb.reverse());
		//System.out.println(sb.subSequence(2,6));
          //System.out.println(sb.substring(3,7));
          sb.setCharAt(8,'y');
		  System.out.println(sb);
		  
		
	}
}