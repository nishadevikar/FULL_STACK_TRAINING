class TypeOver3
{
	void display(StringBuffer a)
	{
		System.out.println("StringBuffer Method");
	}
	void display(String a)
	{
		System.out.println("String Method");
	}
	public static void main(String[] args)
	{
		TypeOver3 to=new TypeOver3();
		to.display("nisha");
		to.display(new StringBuffer("yash"));//instantiation of objects
	}
}
//C:\Users\Nisha.devikar\Desktop>java TypeOver3
//String Method

//StringBuffer Method