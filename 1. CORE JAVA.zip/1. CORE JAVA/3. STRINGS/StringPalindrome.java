//write a program to check if the given string is palindrome or not by using string
class StringPalindrome
{
	public static void main(String[] args)
	String s = args[0];
	String test = "";
	
	for(int i = s.length() - 1; i >=0; i--)
	{
		test += s.charAt(i);
	}
	
	if(s.equalsIgnoreCase(test))
	{
		System.out.println("Palindrome");
	}
	else
	{
		System.out.println("Not a Palindrome");
	}
}
