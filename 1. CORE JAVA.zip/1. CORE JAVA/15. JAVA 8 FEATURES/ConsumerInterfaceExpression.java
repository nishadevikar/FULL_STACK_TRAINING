// consumer interface to store lambda expression in a avariable

import java.util.ArrayList;
import java.util.function.Consumer;

public class ConsumerInterfaceExpression {
  public static void main(String[] args) {
    ArrayList<Integer> numbers = new ArrayList<Integer>();
    numbers.add(5);
    numbers.add(9);
    numbers.add(8);
    numbers.add(1);
    Consumer<Integer> method = (n) -> { System.out.println(n); };
    numbers.forEach( method );
  }
}

/*5
9
8
1*/