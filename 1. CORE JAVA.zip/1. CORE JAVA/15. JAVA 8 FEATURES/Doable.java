
//interface can extend another interface, no need for abstract class
interface sayable{  
    void say(String msg);   // abstract method  
}  
  
interface Doable extends sayable{  
    // Invalid '@FunctionalInterface' annotation; Doable is not a functional interface  
    void doIt();  
}

//compile time error