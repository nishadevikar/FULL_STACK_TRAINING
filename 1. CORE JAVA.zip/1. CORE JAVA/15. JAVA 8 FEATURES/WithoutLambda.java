interface Dancing{  
    public void dance();  
}  
public class WithoutLambda {  
    public static void main(String[] args) {  
        int height=10;  
  
        //without lambda, Dancing implementation using anonymous class  
        Dancing d=new Dancing(){  
            public void dance(){System.out.println("Dancing "+height);}  
        };  
        d.dance();  
    }  
}  