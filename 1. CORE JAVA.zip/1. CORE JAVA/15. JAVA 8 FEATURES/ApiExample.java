import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;


public class ApiExample {

   public static void main(String args[]) {
      ApiExample a1 = new ApiExample();
      a1.testLocalDateTime();
   }
	
   public void testLocalDateTime() {
     
      LocalDateTime currentTime = LocalDateTime.now();
      System.out.println("Current DateTime: " + currentTime);
		
      LocalDate date1 = currentTime.toLocalDate();
      System.out.println("date1: " + date1);
		
 
		
      
      LocalTime date4 = LocalTime.of(22, 15);
      System.out.println("date4: " + date4);
		
      //parse a string
      LocalTime date5 = LocalTime.parse("15:52:30");
      System.out.println("date5: " + date5);
   }
}

/*Current DateTime: 2022-04-11T15:52:56.210
date1: 2022-04-11
date4: 22:15
date5: 15:52:30*/