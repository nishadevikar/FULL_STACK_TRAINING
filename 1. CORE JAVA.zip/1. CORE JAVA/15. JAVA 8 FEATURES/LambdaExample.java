interface Dancing{  
    public void dance();  
}  
  
public class LambdaExample {  
    public static void main(String[] args) {  
        int height=10;  
          
        //with lambda  
        Dancing d2=()->{  
            System.out.println("Dancing "+height);  
        };  
        d2.dance();  
    }  
}  