//forName synatx Example
class Test{}  //{} open and close which means reflection of one bracket 
    
public class ReflectionExample{    
 public static void main(String args[]) throws Exception {    
  Class c=Class.forName("Simple");    
  System.out.println(c.getName());    
 }    
}    