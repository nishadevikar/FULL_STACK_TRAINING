
//static inner class
class Outer
{
	
	static class Inner
	{
		void show()
	    {
		    System.out.println("Outer Show");
	    }
	}
}
public class OuterDemo2
{
	public static void main(String[] args)
	{
		//Outer o=new Outer();
		Outer.Inner oi=new Outer.Inner(); //static inner class
		oi.show();
	}
		
}
/*C:\Users\Nisha.devikar\Desktop>javac OuterDemo.java

C:\Users\Nisha.devikar\Desktop>java OuterDemo
Outer Show /