import java.lang.RuntimeException;
interface libraryFunction{
	public void registerAccount();
	public void requestBook();
}

class KidUser implements libraryFunction{
	private int age;
	private String BookType;
	
	KidUser(int age, String BookType){
		this.age = age;
		this.BookType = BookType;
	}
	
	public void registerAccount(){
		if(this.age > 12){
			throw new NotAKidException("Must be a less than 12 to register a kid");
		}
		System.out.println("Registered for kids account");
	}
	
	public void requestBook(){
		if(!this.BookType.equals("KIDS")){
			throw new CanNotIssueAdultBook("You are requesting an adult Book while being a kid");
		}
		System.out.println("Requested book from kids account");
	}
}

class AdultUser implements libraryFunction{
	private int age;
	private String BookType;
	
	
	AdultUser(int age, String BookType){
		this.age = age;
		this.BookType = BookType;
	}
	
	public void registerAccount(){
		if(this.age < 12){
			throw new NotAnAdult("Must be older than 12 to register an adult");
		}
		System.out.println("Registered for an adult acount");
	}
	
	public void requestBook(){
		if(!this.BookType.equals("Fiction")){
			throw new CanNotIssueKidsBook("You are requesting an kids Book while being an adult");
		}
		System.out.println("Request book from Adult Account");
	}
}

class Library{
	public static void main(String[] args){
		KidUser one = new KidUser(10,"KIDS");
		AdultUser two = new AdultUser(21, "Fiction");
		
		one.registerAccount();
		one.requestBook();
		
		two.registerAccount();
		two.requestBook();
		
		KidUser three = new KidUser(21,"Fiction");
		AdultUser four = new AdultUser(11, "KIDS");
		
		//three.registerAccount(); // NotAKidException
		//three.requestBook(); // CanNotIssueAdultBook
		
		//four.registerAccount(); // NotAnAdult
		four.requestBook(); // CanNotIssueKidsBook
		
	}
}

class NotAKidException extends RuntimeException{
	NotAKidException(String s){
		super(s);
	}
}

class NotAnAdult extends RuntimeException{
	NotAnAdult(String s){
		super(s);
	}
}

class CanNotIssueAdultBook extends RuntimeException{
	CanNotIssueAdultBook(String s){
		super(s);
	}
}

class CanNotIssueKidsBook extends RuntimeException{
	CanNotIssueKidsBook(String s){
		super(s);
	}
}