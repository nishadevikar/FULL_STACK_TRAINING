interface Planting
{  
 void eat();  
}  
class TestAnnonymousInner1
{  
 public static void main(String args[])
 {  
 Planting e=new Planting()
 {  
  public void eat(){System.out.println("nice fruits");
  }  
 };  
 e.eat();  
 }  
}  