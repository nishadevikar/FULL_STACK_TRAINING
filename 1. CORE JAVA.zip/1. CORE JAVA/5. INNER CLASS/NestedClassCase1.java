class Outer
{
	int a=10;
   void show1()
   {
      System.out.println("Hello outer method");
   }
    class Inner
   {
	    void show()
   {
	   System.out.println("Inner show method" + a);
   }
   }
 }
 public class NestedClassCase1
 {
	 public static void main(String args[])
	 {
		 Outer o=new Outer();
		 o.show1(); 
		 Outer.Inner oi=o.new Inner();
		 oi.show();
	 }
 }