class Outer
{
    void Show1()
	{
	
	
	}
	
	static class Inner
	{
		void show()
	    {
		    System.out.println("Outer Show");
	    }
	}
}
public class OuterDemo3
{
	public static void main(String[] args)
	{
		//Outer o=new Outer();
		Outer.Inner oi=new Outer.Inner(); //static inner class
		oi.show();
	}
		
}
//Outer Show