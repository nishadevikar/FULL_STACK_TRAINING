class Outer
{
	static int a=10;
   void show1()
   {
      System.out.println("Hello outer method");
   }
    private static class Inner
   {
	    void show()
   {
	   System.out.println("Inner show method " + a);
   }
   }
 }
 public class NestedClassCase4
 {
	 public static void main(String args[])
	 {
		 Outer o=new Outer();
		 o.show1(); 
		 Outer.Inner oi=new Outer.Inner();
		 oi.show();
	 }
 }
 
 //inner has private access in outer