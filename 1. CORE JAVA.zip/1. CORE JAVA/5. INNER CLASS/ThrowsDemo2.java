import java.io.*;  

class M1
{  
 void method()throws IOException
 {  
  throw new IOException("System Error");  
 }  
}  
public class ThrowsDemo2
{  
   public static void main(String args[])
   {  
    try
	{  
     M1 m=new M1();  
     m.method();  
    }catch(Exception e)
	{
	System.out.println("exception handled carefully");
	}     
  
    System.out.println("Hello normal");  
  }  
}

/*C:\Users\Nisha.devikar\Desktop>javac ThrowsDemo2.java

C:\Users\Nisha.devikar\Desktop>java ThrowsDemo2
exception handled carefully
Hello normal*/