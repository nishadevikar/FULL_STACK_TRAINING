interface LibraryUser
{
   void registerAccount();
   void requestBook();
 }
 
class KidsUser implements LibraryUser
{
  private int age;
   String bookType;
   
    void set(int ag,String bn)
   {
       age=ag;
	   bookType=bn;
	   }
   public void registerAccount()
   {
       if(age<12)
	   {
	   System.out.println("You have successfully registered under a kids Account: ");
   }
   
      else
	  {
	  System.out.println("Sorry..age must be less than 12 to register as kid: ");
	  }
	}  
	    public void requestBook()
   {
       if(bookType.equals("kids"))
	   {
	   System.out.println("Book issued successfully: ");
   }
   
      else
	  {
	  System.out.println("OOPs.. you are  allowed to take only kids books");
	  }
	  }
 }
 
class AdultUser implements LibraryUser
{
  private int age;
   String bookType;
   
   void set(int ag,String bn)
   {
       age=ag;
	   bookType=bn;
	   }
   public void registerAccount()
   {
       if(age>12)
	   {
	   System.out.println("You have successfully registered under a adult Account: ");
   }
   
      else
	  {
	  System.out.println("Sorry..age must be greater than 12 to register as adult: ");
	  }
	}  
	     public void requestBook()
   {
       if(bookType.equals("Fiction"))
	   {
	   System.out.println("Book issued successfully: ");
   }
   
      else
	  {
	  System.out.println("OOPs.. you are  allowed to take only adult fiction books");
	  }
	  }
 }
 
 class LibraryInterfaceDemo
 {
    public static void main(String args[])
	{
	   KidsUser k=new KidsUser();
	   AdultUser a=new AdultUser();
	   k.set(6,"Kids");
	   a.set(22,"Fiction");
	   
	   k.registerAccount();
	   k.requestBook();
	   
	   a.registerAccount();
	   a.requestBook();
	   
	   }
	   }
	   
	   /*C:\Users\Nisha.devikar\Desktop>java LibraryInterfaceDemo
You have successfully registered under a kids Account:
OOPs.. you are  allowed to take only kids books
You have successfully registered under a adult Account:
Book issued successfully:*/