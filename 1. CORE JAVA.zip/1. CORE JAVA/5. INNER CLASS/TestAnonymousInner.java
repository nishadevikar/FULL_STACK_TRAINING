abstract class Plant{  
  abstract void planting();  
}  
class TestAnonymousInner{  
 public static void main(String args[]){  
  Plant p=new Plant(){  
  void planting(){System.out.println("nice fruits");}  
  };  
  p.planting();  
 }  
}  
//nice fruits