import java.io.*;
import java.util.Scanner;
class Employee implements Serializable
{
	double salary;
	String Name;
	String department;
	String designation;
	public void setName(String Name)
   {
    this.Name=Name;
   }
   public void setDepartment(String department)
   {
    this.department=department;
   }
   public void setDesignation(String designation)
   {
    this.designation=designation;
   }
   public void setSalary(double salary)
   {
    this.salary=salary;
   }
   
   public String getName()
   {
    return Name;
   }
   public String getDepartment()
   {
    return department;
   }
   public String getDesignation()
   {
    return designation;
   }
   public double getSalary()
   {
    return salary;
   }
	
	public String tostring()
	{
		return salary+ "" +Name +" " +department + " " +designation;
	}
}
class EmployeeSetter
{
	public static void main(String[] args) throws Exception
	{
	  Employee e=new Employee();
	System.out.println("Enter EmpName");
		Scanner n=new Scanner(System.in);
		String name=n.next();
		e.setName(name);
	System.out.println("Enter Department");
		Scanner d=new Scanner(System.in);
		String department=d.next();
		e.setDepartment(department);
	System.out.println("Enter designation");
		Scanner dn=new Scanner(System.in);
		String designation=dn.next();
		e.setDesignation(designation);
	System.out.println("Enter Salary");
		Scanner s=new Scanner(System.in);
		double salary=s.nextDouble();
		e.setSalary(salary);
	
	    
		
		
		File f=new File("d:/yash/xyz.tx");//yash.txt
		f.createNewFile();
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
	
		
		ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f));//FileInputStream to read input from file
		Employee r=(Employee)ois.readObject();
		ois.close();
		System.out.println(r);
	}
}