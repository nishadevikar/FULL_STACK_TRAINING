import java.io.*;  
class ByteArrayOutputDemo
 {  
public static void main(String args[])throws Exception
{    
      FileOutputStream fout1=new FileOutputStream("d:/yash/abc.txt");    
      FileOutputStream fout2=new FileOutputStream("d:/yash/xyz.txt");    
        
      ByteArrayOutputStream bout=new ByteArrayOutputStream();    
      bout.write(80);    
      bout.writeTo(fout1);    
      bout.writeTo(fout2);    
        
      bout.flush();  //Flushes data from output side in buffer part.   
      bout.close();   
      System.out.println("Run Successfully...");    
     }    
    }   
	//P letter is printed in the two txt files