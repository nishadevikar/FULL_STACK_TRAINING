import java.io.File;
import java.io.IOException;
class FileDemo2
{
	public static void main(String[] args) throws IOException
	{
		File f=new File("d:/yash/abc.txt");
		f.createNewFile(); //for creating new file
		System.out.println(f.exists());//chheck existing or not
		System.out.println(f.canWrite());//can we write
		System.out.println(f.canWrite());//get name of file
		System.out.println(f.length());//size
		f.delete();//delete the file
	}
}

/*true
true
true
0*/

