import java.io.*;  
public class DataOutputDemo
 {  
    public static void main(String[] args) throws IOException {  
        FileOutputStream file = new FileOutputStream("d:/yash/abc.txt");  
        DataOutputStream data = new DataOutputStream(file);  
        data.writeInt(60);  
        data.flush();  
        data.close();  
        System.out.println("Succcess...");  
    }  
} 
// C:\Users\Nisha.devikar\Desktop>java DataOutputDemo
//Succcess...

//   <