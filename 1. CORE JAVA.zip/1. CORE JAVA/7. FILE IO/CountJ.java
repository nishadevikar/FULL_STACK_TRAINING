import java.io.*;
import java.util.Scanner;


public class CountJ {
    public static void main(String[] args)throws IOException
    {

        String fileName = "d:/yash/yash1.txt";
        String line = "";
        Scanner scanner = new Scanner(new FileReader(fileName));
		
		//Scanner input = new Scanner(System.in);

		
        try {

          while ( scanner.hasNextLine() ){
            line = scanner.nextLine();
            int counter = 0;

            for( int i=0; i<line.length(); i++ ) {
                if( line.charAt(i) == 'J' ) 
				{
                    counter++; 

                } 


            }

             System.out.println(counter);   
          }
        }
        finally 
		{

          scanner.close();
        }
    }
}

//Jaynam Sir is our official Technical Trainer
//1       (J appers only 1 time)
	