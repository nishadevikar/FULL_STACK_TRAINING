import java.io.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

class Employee12
{
	String name;
	String dessignation;
	double Salary;
	
	//getter and setter methods
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	
	public String getDessignation()
	{
		return dessignation;
	}
	public void setDessignation(String dessignation)
	{
		this.dessignation=dessignation;
	}
	
	public double getSalary()
	{
		return salary;
	}
	public void setSalary(double salary)
	{
		this.salary=salary;
	}
	
	//override method
	    public String toString() 
		{
			return"Employee12 [name=" + name + ", designation=" + designation + ", salary=" + salary + "]";
		}
}


public class EmployeeDetails
{
	public static void main(String[] args) throws IOException
{
	Scanner sc = new Scanner(System.in); //to take input from the keyboard

    Employee12 emp = new Employee12();

    System.out.print("Enter name: ");

    emp.setName(sc.nextLine());

    System.out.print("Enter designation: ");

    emp.setDesignation(sc.nextLine());

    System.out.print("Enter salary: ");

    emp.setSalary(sc.nextDouble());

    sc.nextLine();

FileOutputStream fos = new FileOutputStream("d:/yash/xyz.txt");

ObjectOutputStream oos = new ObjectOutputStream(fos);

oos.writeObject(emp);



FileInputStreamfis = new FileInputStream("d:/yash/abc.txt");

ObjectInputStream ois = new ObjectInputStream(fis);

Employee12 emp2 = (Employee12) ois.readObject();



System.out.println("Name: " + emp2.getName());
System.out.println("Designation: " + emp2.getDesignation());
System.out.println("Salary: " + emp2.getSalary());

fos.close();
oos.close();
fis.close();
ois.close();
sc.close();

}
}

		
	
	