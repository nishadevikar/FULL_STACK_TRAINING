import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

class FileInputOutputStreamDemo
{
	public static void main(String[] args) throws Exception
	{
		FileInputStream in=new FileInputStream("d:/yash/abc.txt");
		FileOutputStream out=new FileOutputStream("d:/yash/xyz.txt");
		int c;
		while((c=in.read())!=-1) //=yas -1
			out.write(c); //yash 
		in.close();
		out.close();
	}
}

//abc content"yash Technologies" will be written in xyz txt file.
