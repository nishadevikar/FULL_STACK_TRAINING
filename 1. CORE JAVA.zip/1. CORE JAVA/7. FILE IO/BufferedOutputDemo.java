import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
class BufferedOutputDemo
{
    public static void main(String args[])
	{
	     try
{
		 
     	FileOutputStream fout=new FileOutputStream("d:/yash/xyz.txt");
		BufferedOutputStream a1=new BufferedOutputStream(fout);
		String s="welcome Nisha in YASH Technologies";
		byte ba[]=s.getBytes();
		a1.write(ba);
		a1.close();
	
		}
		catch(Exception e)
		{ 
		  e.printStackTrace();
		  }
		  }
		  }