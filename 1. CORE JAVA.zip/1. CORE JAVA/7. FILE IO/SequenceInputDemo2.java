import java.io.*;    
class SequenceInputDemo2
{    
  public static void main(String args[])throws Exception{    
   FileInputStream fin1=new FileInputStream("d:/yash/abc.txt");    
   FileInputStream fin2=new FileInputStream("d:/yash/xyz.txt");    
   FileOutputStream fout=new FileOutputStream("d:/yash/combine.txt");      
   SequenceInputStream s1=new SequenceInputStream(fin1,fin2);    
   int i;    
   while((i=s1.read())!=-1)    
   {    
     fout.write(i);        
   }    
   s1.close();    
   fout.close();      
   fin1.close();      
   fin2.close();       
   System.out.println("Program is Successfully Run..");  
  }    
}    