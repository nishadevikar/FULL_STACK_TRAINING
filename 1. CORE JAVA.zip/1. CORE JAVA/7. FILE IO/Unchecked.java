import java.io.*;
class Unchecked
{
	public static void main(String[] args)
	{
		int a[] = {1, 2, 3, 4, 5};
		try
		{
			System.out.println(a[5]);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Out of index");
		}
		try
		{
			System.out.println(100/0);
		}
		catch(ArithmeticException e)
		{
			System.out.println("Out of format");
		}
			
	}
}
	