import java.io.*;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
class FileReaderWriter
{
	public static void main(String[] args) throws IOException
	{
		File f=new File("d:/yash/FileReadWrite.txt");
		f.createNewFile();
		FileWriter w=new FileWriter(f);
		w.write("Welcome to Yash");
		w.close();
		FileReader r=new FileReader(f);
		char[] a=new char[20];
		r.read(a); //read and store
		for(char c:a)
			System.out.println(c); //one by one character will be printed
		r.close();
	}
}

/*C:\Users\Nisha.devikar\Desktop>java FileReaderWriter
W
e
l
c
o
m
e

t
o

Y
a
s
h*/