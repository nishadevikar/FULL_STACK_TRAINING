import java.io.*;

class Employee1 implements Serializable
{
	int empId;
	String empName;
	Employee1(int empId, String empName)
	{
		this.empId=empId;
		this.empName=empName;
	}
	public String toString()
	{
		return empId + " " +empName;
	}
}
class Employee1ObjectDemo
{
	    public static void main(String[] args) throws Exception
		{
			Employee1 e=new Employee1(27, "Nisha");  //java EmployeeObjectDemo
			System.out.println(e);
			File f=new File("d:/yash/xyz.txt");
			//ObjectOutputStream ois=new ObjectOutputStream(new FileOutputStream(f));
			
			ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
			oos.writeObject(e);
			oos.close();
			
		}
}

//27 Nisha
