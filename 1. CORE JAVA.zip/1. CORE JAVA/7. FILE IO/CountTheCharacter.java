import java.io.*;
import java.util.Scanner;


public class CountTheCharacter 
{
    public static void main(String[] args)throws IOException
    {

        String fileName = "Yash1.txt";
        String line = "";
        Scanner scanner = new Scanner(new FileReader(fileName));
        try {

         
            int counter = 0;
while ( scanner.hasNextLine() ){
// ...
}
System.out.println(counter);

            for( int i=0; i<line.length(); i++ ) {
                if( line.charAt(i) == 'a' ) {
                    counter++; 

                } 


            }

             System.out.println(counter);   
          }
        }
        finally {

          scanner.close();


    }}}