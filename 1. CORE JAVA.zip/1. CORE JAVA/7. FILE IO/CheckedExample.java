
import java.io.*;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.IOException;
//import java.io.ClassNotFoundException;

class CheckedException
{
	public static void main(String[] args) 
	{
		FileInputStream fin = null;
		try
		{
			fin = new FileInputStream("d:/yash/abc.txt");
		}
		catch(FileNotFoundException e)
		{
			System.out.println("File Doesn't exist");
		}
		try
		{
			Class.forName("The Class do not Exist");
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		int k;
		try
		{
			while((k=fin.read())!=-1)	
			
			{
				System.out.println((char)k);
			}
			fin.close();
		}
		catch(IOException eff)
		{
			System.out.println("Error Has Occurred");
		}
	}
}
		

