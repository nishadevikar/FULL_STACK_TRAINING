import java.io.*;
class SequenceInputDemo
{
	public static void main(String args[]) throws IOException
	{
		    FileInputStream f1=new FileInputStream("d:/yash/xyz.txt");
			FileInputStream f2=new FileInputStream("d:/yash/abc.txt");
			SequenceInputStream st=new SequenceInputStream(f1,f2);
			int i;
			while((i=st.read())!=-1)
			{
				System.out.print((char)i);
			}
			st.close();
			f1.close();
			f2.close();
	}
}

//welcome Nisha in YASH TechnologiesWelcome Everyone in Yash