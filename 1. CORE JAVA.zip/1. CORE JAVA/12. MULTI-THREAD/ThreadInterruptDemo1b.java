public class ThreadInterruptDemo1b extends Thread
{
	public void run()
	{
		System.out.println(Thread.interrupted()); //true
		for(int i=1;i<=3;i++)
		{
			try {
			System.out.println(i);
			Thread.sleep(1000);
			System.out.println(Thread.interrupted()); //true-->current status---> true---->False
			System.out.println(Thread.currentThread().isInterrupted());
			}
			catch(Exception e)
			{
				e.printStackTrace();
				//System.out.println(e); // sleep interrupted
			}
		}
	}
	public static void main(String[] args)
	{
		ThreadInterruptDemo1b t1=new ThreadInterruptDemo1b();
		t1.start(); //Thread-0
		t1.interrupt(); //true
	}
}
		
	/*true
1
false
false
2
false
false
3
false
false*/