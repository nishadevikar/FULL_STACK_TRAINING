public class ThreadDemo1 implements Runnable
{
	public void run()
	{
		System.out.println("Thread Started");
	}
	public static void main(String[] args)
	{
		//ThreadDemo t=new ThreadDemo();
		Thread t=new Thread(new ThreadDemo1());
		t.start();
	}
}

//start is used to call the run(_), when start is called a new stack is given to the thread and run() is invoked in new thread

//Thread Started will be the output.