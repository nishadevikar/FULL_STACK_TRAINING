import java.util.*;
public class Main {
 public static void main(String args[]) 
 {
 int tab[] = new int [6];
 for (int i = 6; i > 0; i--)
 tab[6-i] = i;
 Arrays.fill(tab, 1, 5, 0); 
 for (int i = 0; i < 6 ; i++)
 System.out.print(tab[i]); 
 }
 } 