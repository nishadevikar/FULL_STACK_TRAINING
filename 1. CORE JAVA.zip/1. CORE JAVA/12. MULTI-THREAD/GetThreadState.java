class GetThreadState extends Thread {
 
    public void run() {
       
        System.out.println("The state of this thread is : " + Thread.currentThread().getState());

        
    }

    public static void main(String[] args) {
        
        GetThreadState gt_state = new GetThreadState();

      
        gt_state.setName("GetThreadState");

        
        gt_state.start();

        
        System.out.println("The name of this thread is " + " " + gt_state.getName());
    }
}