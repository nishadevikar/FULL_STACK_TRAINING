public class ThreadDaemonDemo extends Thread
{
	public void run()
	{
		System.out.println("In run method");
		if (Thread.currentThread().isDaemon()) //check if it is Daemon
		{
			System.out.println("I am in Daemon Thread");
		}
		else
		{
			System.out.println("I am in Daemon Thread");
		}
			
	}
	public static void main(String[] args) 
	{
		System.out.println("Main Thread");
		ThreadDaemonDemo td=new ThreadDaemonDemo();
		td.setDaemon(true);
		td.start();
	}
}
		
