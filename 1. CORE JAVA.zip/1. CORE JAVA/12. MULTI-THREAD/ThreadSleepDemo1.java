public class ThreadSleepDemo1 extends Thread
{
	public void run()
	{
		for(int i=1;i<=3;i++)
		{
			try {
				//Thread.sleep(100); //interrupted Exception
				System.out.println(Thread.currentThread().getName());
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			System.out.println(i);
		}
	}
	public static void main(String[] args) 
	{
		ThreadSleepDemo1 ts1=new ThreadSleepDemo1();
		ts1.setName("Yash Technologies");
		ts1.setPriority(10);
		ts1.start();
		ThreadSleepDemo1 ts2=new ThreadSleepDemo1();
		ts2.setName("Nisha");
		ts2.setPriority(1);
		ts2.start();
	}
}

/*Nisha
Yash Technologies
1
Yash Technologies
2
Yash Technologies
3
1
Nisha
2
Nisha
3*/