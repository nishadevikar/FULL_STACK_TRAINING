class BookTicket
{
	int totalseats=12;
	void bookseat(int seats)
	{
		synchronized(this)  //Synchronized block which is applicable only for the if else
		{
		if(totalseats>=seats)
		{
			System.out.println("Booked Successfully");
			totalseats=totalseats-seats;
			System.out.println("Remaining seats"+totalseats);
		}
		else
		{
			System.out.println("Seats are not available"+totalseats);
		}
		} //object lock
	}
}
public class TicketWithSynch extends Thread
{	static BookTicket b;
	int seats;
	public void run()
	{
		b.bookseat(seats);
	}
	public static void main(String[] args)
	{
		b=new BookTicket();
		TicketWithSynch p1=new TicketWithSynch();
		p1.seats=8;
		p1.start();
		TicketWithSynch p2=new TicketWithSynch();
		p2.seats=10;
		p2.start();
	}
}
		
	
/*Booked Successfully
Booked Successfully
Remaining seats2
Remaining seats-6*/