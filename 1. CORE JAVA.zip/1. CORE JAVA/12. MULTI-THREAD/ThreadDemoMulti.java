
class MyThread1 extends Thread
{
	public void run()
	{
		System.out.println("I am in mythread1");
	}
}
class MyThread2 extends Thread
{
	public void run()
	{
		System.out.println("I am in mythread2");
	}
}
class MyThread3 extends Thread
{
	public void run()
	{
		System.out.println("I am in mythread3");
	}
}
public class ThreadDemoMulti
{
	public static void main(String[] args)
	{
		MyThread1 t=new MyThread1(); //single thread
		t.start();
		MyThread2 t1=new MyThread2(); //multiple thread
		t1.start();
		MyThread3 t2=new MyThread3(); //multiple thread
		t2.start();
	}
}

/*I am in mythread1
I am in mythread2
I am in mythread3*/