class BookTicket
{
	static int totalseats=12;
	static synchronized void bookseat(int seats)
	{
		//synchronized(this)  //Synchronized block which is applicable only for the if else
		{
		if(totalseats>=seats)
		{
			System.out.println("Booked Successfully");
			totalseats=totalseats-seats;
			System.out.println("Remaining seats"+totalseats);
		}
		else
		{
			System.out.println("Seats are not available"+totalseats);
		}
		} //object lock
	}
}
class Thread1 extends Thread
{	static BookTicket b;
	int seats;
	Thread1(BookTicket b,int seats)
	{
		this.b=b;
		this.seats=seats;
	}
	public void run()
	{
		b.bookseat(seats);
	}
}

class Thread2 extends Thread
{	static BookTicket b;
	int seats;
	Thread2(BookTicket b,int seats)
	{
		this.b=b;
		this.seats=seats;
	}
	public void run()
	{
		b.bookseat(seats);
	}
}
    public class TicketWithSynch1 extends Thread 
{
	public static void main(String[] args)
	{
		BookTicket b=new BookTicket();
		Thread1 t1=new Thread1(b,8);
		t1.start();
		Thread2 t2=new Thread1(b,3);
		t2.start();
		Thread2 t3=new Thread1(b1,3);
		t3.start();
		Thread2 t4=new Thread1(b1,4);
		t4.start();
	}
}
		
	
