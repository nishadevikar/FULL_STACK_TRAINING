public class ThreadJoinDemo extends Thread
{
	static Thread mt;
	
	public void run()
	{
		try
		{
			mt.join();
			for(int i=1;i<=3;i++)
			{
				System.out.println("run thread" + i);
				Thread.sleep(1000);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public static void main(String[] args) throws Exception
	{
		 mt=Thread.currentThread();
		ThreadJoinDemo tj=new ThreadJoinDemo();
		tj.start();
		//tj.join();
		try{
			for(int i=1;i<=3;i++)
			{
				System.out.println("Main thread" + i);
				Thread.sleep(1000);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		}
	}

/*run thread1
run thread2
run thread3
Main thread1
Main thread2
Main thread3*/
	