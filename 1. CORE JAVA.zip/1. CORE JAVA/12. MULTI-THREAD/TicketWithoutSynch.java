class BookTicket
{
	int totalseats=12;
	void bookseat(int seats)
	{
		if(totalseats>=seats)
		{
			System.out.prinln("Booked Successfully");
			totalseats=totalseats-seats;
			System.out.prinln("Remaining seats"+totalseats);
		}
		else
		{
			System.out.prinln("Seats are not available"+totalseats);
		}
	}
}
public class TicketWithSynch extends Thread
{	static BookTicket b;
	int seats;
	public void run()
	{
		b.bookseat(seats);
	}
	public static void main(String[] args)
	{
		b=new BookTicket();
		TicketWithoutSynch p1=new TicketWithoutSynch();
		p1.seats=8;
		p1.start();
		TicketWithoutSynch p2=new TicketWithoutSynch();
		p2.seats=8;
		p2.start();
	}
}
		
	
	