//single task using single thread
public class ThreadDemo12 implements Runnable
{
	public void run()
	{
		System.out.println("Thread Started");
	}
	public static void main(String[] args)
	{
		ThreadDemo t=new ThreadDemo(); //single thread
		t.start();
		ThreadDemo t1=new ThreadDemo(); //multiple thread
		t1.start();
		}
		}