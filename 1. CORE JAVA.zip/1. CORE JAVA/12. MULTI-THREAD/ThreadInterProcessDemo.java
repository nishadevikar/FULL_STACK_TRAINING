class Revenue extends Thread
{
	int total=0;
	public void run()
	{
		synchronized(this)
		{
		for(int i=1;i<=5;i++)
		{
			total=total+400;
		}
		this.notify(); //lock again given to main
		}
	}
}

public class ThreadInterProcessDemo
{
	public static void main(String[] args) throws Exception
	{
		Revenue r=new Revenue();
		r.start(); //thread 0
		//System.out.println("Total Amount" + r.total);  //Total Amount0 is printed
		synchronized(r)
		{
			r.wait(); //object lock main given to thread 0
			System.out.println("Total Amount" + r.total); //Total Amount2000 is printed
		}
	}
}
//Total Amount2000