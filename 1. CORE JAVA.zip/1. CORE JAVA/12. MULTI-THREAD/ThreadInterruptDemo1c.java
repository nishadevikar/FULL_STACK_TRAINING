public class ThreadInterruptDemo1c extends Thread
{
	public void run()
	{
		System.out.println(Thread.currentThread().getName()+""+Thread.currentThread().isInterrupted());
			try {
				for(int i=1;i<=3;i++)
				{
					System.out.println(i);
					Thread.sleep(1000);
				}
			}
			catch(Exception e)
			{
				System.out.println(e); // sleep interrupted
			}
	}
	public static void main(String[] args)
	{
		ThreadInterruptDemo1c t1=new ThreadInterruptDemo1c();
		t1.start(); //Thread-0
		t1.setName("Thread-1");
		t1.interrupt(); //true
		ThreadInterruptDemo1c t2=new ThreadInterruptDemo1c();
		t2.start(); //Thread-0
		t2.setName("Thread-2");
		t2.interrupt();
	}
}
		
/*Thread-2true
1
Thread-1true
1
java.lang.InterruptedException: sleep interrupted
java.lang.InterruptedException: sleep interrupted*/