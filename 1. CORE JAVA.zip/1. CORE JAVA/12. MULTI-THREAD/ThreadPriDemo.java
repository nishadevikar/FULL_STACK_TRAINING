public class ThreadPriDemo extends Thread
{
	public void run()
	{
		System.out.println("In run Method");
		System.out.println(Thread.currentThread().getPriority());
	}
	public static void main(String[] args)
	{
		System.out.println(Thread.currentThread().getPriority());
		Thread.currentThread().setPriority(MIN_PRIORITY); //10
		ThreadPriDemo tp=new ThreadPriDemo();
		tp.setPriority(7);
		tp.start();
	}
}
		