public class ThreadInterruptDemo extends Thread
{
	public void run()
	{
		try
		{
			for(int i=1;i<=3;i++)
			{
				System.out.println(i); //1
				//Thread.sleep(2000);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String[] args)
	{
		ThreadInterruptDemo ti=new ThreadInterruptDemo();
	    ti.start();
		ti.interrupt();
	}
}

	/*1
java.lang.InterruptedException: sleep interrupted
        at java.lang.Thread.sleep(Native Method)
        at ThreadInterruptDemo.run(ThreadInterruptDemo.java:10)*/		
		
		/*1
          2
          3*/
	