class EnumOridinalDemo
{
	enum Directions{
	EAST,WEST,NORTH,SOUTH;}
	public static void main(String[] args)
	{
		for(Directions d:Directions.values())
		{
			System.out.println(d);
		}
		System.out.println("Value of:"+Directions.valueOf("WEST"));
		System.out.println("Index of:"+Directions.valueOf("NORTH").ordinal());
	}
}

/*EAST
WEST
NORTH
SOUTH
Value of:WEST
Index of:2*/