class EnumInSwitch 
{
	enum Day 
	{

        MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;
    }

    public static void main(String args[]) 
	{

        Day[] daysOfWeek = Day.values();

        for (Day X : daysOfWeek) 
		{

            //Using Enum in Switch case statement

            switch (X) 
			{
                case MONDAY:
                    System.out.println("28 March was Monday");
                    break;
                case TUESDAY:
                    System.out.println("29 March was Tuesday");
                    break;
                case WEDNESDAY:
                    System.err.println("30 March was Wednesday");
                    break;
                case THURSDAY:
                    System.err.println("31 March is Thursday");
                    break;
                case FRIDAY:
                    System.err.println("1 April will be Friday");
                    break;
                case SATURDAY:
                    System.err.println("2 April will be Saturday");
                    break;
                case SUNDAY:
                    System.err.println("3 April will be Sunday : HOLIDAY");
                    break;
					System.out.println("Value of:"+Day.valueOf("MONDAY"));
					System.out.println("Index of:"+Day.valueOf("MONDAY").ordinal());
			    
			}
        }
    }
}

