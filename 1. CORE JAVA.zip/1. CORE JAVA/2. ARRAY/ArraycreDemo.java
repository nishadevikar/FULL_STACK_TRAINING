//1D Array
class ArraycreDemo
{
    public static void main(String args[])
	{    int[] a=new int[3]; //creating 1D Array
		System.out.println(a);
	}
		
}
/*C:\Users\Nisha.devikar\Desktop>javac ArraycreDemo.java
C:\Users\Nisha.devikar\Desktop>java ArraycreDemo
[I@15db9742*/