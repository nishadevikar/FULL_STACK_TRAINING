// Java program to print supersequence of two
// strings
public class GFG_1 {
     
    String a , b;
     
    // Prints super sequence of a[0..m-1] and b[0..n-1]
    static void printSuperSeq(String a, String b)
    {
        int m = a.length(), n = b.length();
        int[][] dp = new int[m+1][n+1];
      
        // Fill table in bottom up manner
        for (int i = 0; i <= m; i++)
        {
            for (int j = 0; j <= n; j++)
            {
               // Below steps follow above recurrence
               if (i == 0)
                   dp[i][j] = j;
               else if (j == 0 )
                   dp[i][j] = i;
               else if (a.charAt(i-1) == b.charAt(j-1))
                    dp[i][j] = 1 + dp[i-1][j-1];
               else
                    dp[i][j] = 1 + Math.min(dp[i-1][j], dp[i][j-1]);
            }
        }
      
       // Create a string of size index+1 to store the result
       String res = "";
      
       // Start from the right-most-bottom-most corner and
       // one by one store characters in res[]
       int i = m, j = n;
       while (i > 0 && j > 0)
       {
          // If current character in a[] and b are same,
          // then current character is part of LCS
          if (a.charAt(i-1) == b.charAt(j-1))
          {
              // Put current character in result
              res = a.charAt(i-1) + res;
      
              // reduce values of i, j and indexs
              i--;
              j--;
          }
      
          // If not same, then find the larger of two and
          // go in the direction of larger value
          else if (dp[i-1][j] < dp[i][j-1])
          {
              res = a.charAt(i-1) + res;
              i--; 
          }
          else
          {
              res = b.charAt(j-1) + res;
              j--;
          }
       }
      
       // Copy remaining characters of string 'a'
       while (i > 0)
       {
           res = a.charAt(i-1) + res;
           i--;
       }
      
       // Copy remaining characters of string 'b'
       while (j > 0)
       {
           res = b.charAt(j-1) + res;  
           j--;
       }
      
       // Print the result
       System.out.println(res);
    }
      
    /* Driver program to test above function */
    public static void main(String args[])
    {
      String a = "HelloWorld";
      String b = "Hweolrlld";
      printSuperSeq(a, b);
       
    }
}