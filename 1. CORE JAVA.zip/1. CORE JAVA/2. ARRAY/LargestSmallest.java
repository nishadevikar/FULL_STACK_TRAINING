class LargestSmallest{
	public static void main(String[] args){
		int[] arr = {4,6,5,7,8,0};
		sort(arr);
		
		System.out.println("Largest Two numbers are : " + arr[arr.length - 1] + ", " + arr[arr.length-2]);
		System.out.println("Smallest Two numbers are : " + arr[0] + ", " + arr[1]);
	}
	
	static void sort(int[] arr){
		for(int i = 0; i < arr.length; i++){
			for(int j = 1; j < arr.length - i;j++){
				if(arr[j] < arr[j-1]){
					swap(arr, j, j-1);
				}
			}
		}
	}
	
	static void swap(int[] arr, int a, int b){
		int temp = arr[a];
		arr[a] = arr[b];
		arr[b] = temp;
	}
}
/*C:\Users\Nisha.devikar\Desktop>java LargestSmallest
Largest Two numbers are : 8, 7
Smallest Two numbers are : 0, 4*/