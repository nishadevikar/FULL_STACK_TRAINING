//initialise array 1D
class ArraycreDemo1
{
    public static void main(String args[])
	{
		Int[] a;
		a=new int[3];
		int a[]=new int[3];   //creating 1D Array
		//a[0]=10, a[1]=20, a[2]=30, a[3]=40
		
		Int a[] = {10, 20, 30, 40}; //Declare, creation and initialise
		Int a[]=new int[]
		System.out.println(a);
	}
		
}
/*C:\Users\Nisha.devikar\Desktop>javac ArraycreDemo.java
C:\Users\Nisha.devikar\Desktop>java ArraycreDemo
[I@15db9742*/