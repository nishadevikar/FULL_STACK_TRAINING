class CheckProgram{
	public static void main(String[] args){
		int[][] a = new int[2][];
		a[0] = new int[3];
		a[1] = new int[2];
		//a[2] = new int[3]; Index Out of bound
		System.out.println(a); // address // same
		System.out.println(a[0]); // null value // same
		System.out.println(a[0][0]); // Null Exception (Since not intialized) // exception gone
		System.out.println(a.length); //2
		//System.out.println(a[0][0].length); //error	
	}
}
/*C:\Users\Nisha.devikar\Desktop>java CheckProgram
[[I@15db9742
[I@6d06d69c
0
2*/