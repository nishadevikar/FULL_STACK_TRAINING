class SortDsc {    
    public static void main(String[] args) {        
             
        int [] a = new int [] {5, 2, 8, 7, 1};     
        int b = 0;    
            
           
        System.out.println("Elements of original array: ");    
        for (int i = 0; i < a.length; i++) 
		{     
            System.out.print(a[i] + " ");    
        }    
            
            
        for (int i = 0; i < a.length; i++) {     
            for (int j = i+1; j < a.length; j++) {     
               if(a[i] < arr[j]) {    
                   b = a[i];    
                   a[i] = a[j];    
                   a[j] = b;    
               }     
            }     
        }    
            
        System.out.println();    
            
            
        System.out.println("Elements of array sorted in descending order: ");    
        for (int i = 0; i < a.length; i++) {     
            System.out.print(a[i] + " ");    
        }    
    }    
}    