class Anonym1
{
    public static void main(String[] args)
	{
	    Anonym1.sum(new int[] {{10,20,30},{40,50}});
	}
	static void sum(int[] no)
	{
	    int total=0;
		for(int ir[]:no)//for each
		{
		    for(int i:ir)
		{
		    total= total+i;
		}
		}
		System.out.println("Sum is:" +total);
	
	}
}