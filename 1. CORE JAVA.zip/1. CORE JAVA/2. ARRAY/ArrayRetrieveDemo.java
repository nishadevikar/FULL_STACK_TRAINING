class ArrayRetrieveDemo
{
	public static void mian(string[] args)
	{
		int[] a={10,20,30}
		for(int i=0;i<a.length; i++)
		{
			system.out.println("a[i] +",");
		}
		for(datatype variablename: array/collection)//forEach Loop
		{
			
		}
		for(int j:a)
		{
			system.out.println(j);
		}
	}
}