class MaxArray{
	public static void main(String[] args){
		int[] a = {1,2,4};
		int[] b = {4,5,7};
		
		int[] c = new int[2];
		
		c[0] = a[a.length/2];
		c[1] = b[b.length/2];
		
		for(int i = 0; i<c.length; i++){
			System.out.print(c[i] + " ");
		}
	}
}

/*C:\Users\Nisha.devikar\Desktop>java MaxArray
2 5*/