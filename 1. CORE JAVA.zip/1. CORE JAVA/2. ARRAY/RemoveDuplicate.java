class RemoveDuplicate{
	public static void main(String[] args){
		int[] a = {9,8,8,5,6,7,7,2,4,5};
		sort(a);
	}
	
	static void sort(int[] arr){
		for(int i = 0; i < arr.length; i++){
			for(int j = 1; j < arr.length - i;j++){
				if(arr[j] < arr[j-1]){
					swap(arr, j, j-1);
				}
			}
		}
		
		for(int i = 0; i < arr.length-1; i++){
			if(arr[i] == arr[i+1] ){
				continue;
			} else{
				System.out.print(arr[i] + " ");
			}
		}
		if(arr[arr.length-2] != arr[arr.length-1]){
			System.out.print(arr[arr.length-1]);
		}
	}
	
	static void swap(int[] arr, int a, int b){
		int temp = arr[a];
		arr[a] = arr[b];
		arr[b] = temp;
	}
}
/*C:\Users\Nisha.devikar\Desktop>java RemoveDuplicate
2 4 5 6 7 8 9*/