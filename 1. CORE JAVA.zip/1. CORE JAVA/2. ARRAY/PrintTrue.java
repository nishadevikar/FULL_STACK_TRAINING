class PrintTrue{
	public static void main(String[] args){
		int[] a = {1,4,1,4,1,4};
		int[] b = {1,3,1,4,1,4,5,6,7};
		
		check(a);
		check(b);
	}
	
	static void check(int[] arr){
		boolean flag = true;
		
		for(int i = 0; i < arr.length; i=i+2){
			if(arr[i] != 1){
				flag = false;
				System.out.println(false);
				return;
			}
		}
		
		for(int j = 1; j < arr.length; j=j+2){
			if(arr[j] != 4){
				flag = false;
				System.out.println(false);
				return;
			}
		}
		
		
		System.out.println(flag);
	}
}

/*C:\Users\Nisha.devikar\Desktop>java PrintTrue
true
false*/