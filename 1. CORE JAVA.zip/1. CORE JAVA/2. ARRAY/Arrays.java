class Arrays{
	public static void main(String[] args){
		int[] a = {1,2,3,4,5,6,7,8,9};
		int[][] arr = {{1,2,3}, {4,5,6}};
		sumAndAverage(a);
		sumAndAverage(arr);
	}
	
	static void sumAndAverage(int [] arr){
		int sum = 0;
		for(int i = 0; i < arr.length; i++){
			sum += arr[i];
		}
		System.out.println("Sum : " + sum);
		System.out.println("Average : " + sum/arr.length * 1.0);
	}
	
	static void sumAndAverage(int[][] arr){
		int sum = 0;
		int length = 0;
		for(int i = 0; i < arr.length; i++){
			for(int j = 0; j < arr[i].length; j++){
				sum += arr[i][j];
				length++;
			}
		}
		System.out.println("Sum : " + sum);
		System.out.println("Average : " + sum/(length * 1.0));
		
	}
}
/*Sum : 45
Average : 5.0
Sum : 21
Average : 3.5*/