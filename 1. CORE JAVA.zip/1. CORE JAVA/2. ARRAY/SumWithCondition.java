class SumWithCondition{
	public static void main(String[] args){
		int[] arr = {2,4,6,2,3,4,7,8};
		
		sumWithCondition(arr);
	}
	
	static void sumWithCondition(int[] arr){
		boolean flag = false;
		int sum = 0;
		for(int i = 0; i < arr.length; i++){
			if(arr[i] == 7){
				flag = false;
			}
			if(flag){
				sum += arr[i];
			}
			if(arr[i] == 6){
				flag = true;
			}
			
		}
		System.out.println(sum);
	}
}
/*C:\Users\Nisha.devikar\Desktop>java SumWithCondition
9*/