class Matrix3x3Max{
	public static void main(String[] args){
		int[][] a = {{1,2,3},{9,5,7},{2,4,6}};
		
		int max = a[0][0];
		for(int i = 0; i < a.length; i++){
			for(int j = 0; j <a[i].length; j++){
				if(a[i][j] > max){
						max = a[i][j];
				}
			}
		}
		System.out.println(max);
	}
}

//9