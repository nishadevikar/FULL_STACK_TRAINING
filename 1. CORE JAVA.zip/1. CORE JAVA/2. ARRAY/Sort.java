class Sort{
	public static void main(String[] args){
		int[] a = {4,6,1,3,5,7,8};
		sort(a);
	}
	
	static void sort(int[] arr){
		for(int i = 0; i < arr.length; i++){
			for(int j = 1; j < arr.length - i;j++){
				if(arr[j] < arr[j-1]){
					swap(arr, j, j-1);
				}
			}
		}
		
		for(int i = 0; i < arr.length; i++){
			System.out.print(arr[i] + " ");
		}
	}
	
	static void swap(int[] arr, int a, int b){
		int temp = arr[a];
		arr[a] = arr[b];
		arr[b] = temp;
	}
}

/*C:\Users\Nisha.devikar\Desktop>java Sort
1 3 4 5 6 7 8*/