class JaggedArray   //2D Jagged Array
{
	public static void main(String[] args)
	{
		int[][] a={{10,20,30},{40,50},{60,70,80}};
		//System.out.println(a);
		//System.out.println(a[0]);
		System.out.println(a[0][0]);
		System.out.println(a.length);
		//System.out.println(a[0][0].length);
	}
}
/*C:\Users\Nisha.devikar\Desktop>java JaggedArray
10
3
*/