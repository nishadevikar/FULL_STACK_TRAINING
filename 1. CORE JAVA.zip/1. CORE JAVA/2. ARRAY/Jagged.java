class Jagged //2D Jagged Array
{
	public static void main(String[] args)
	{
		Int[][] a={{10,20,30},{40,50},{60,70,80}};
		System.out.println(a);
	}
}
/*
C:\Users\Nisha.devikar\Desktop>javac Jagged.java
C:\Users\Nisha.devikar\Desktop>java Jagged
[[I@15db9742*/