public class Assign
{
   public static void main(String[] args) {
     int num1, num2;
     num1 = Integer.parseInt(args[0]);
     num2 = Integer.parseInt(args[1]);
   System.out.println(“the bigger value of the two is : “ + getMax(num1, num2));
}
   public static int getMax(int num1, int num2) {
     int result;
     if (num1 > num2)
         result = num1;
     else
        result = num2;

   return result; 
   }
}