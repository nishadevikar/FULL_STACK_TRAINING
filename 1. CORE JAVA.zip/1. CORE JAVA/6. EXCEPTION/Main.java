
import java.io.*;
import java.util.*;
public class Main
{
 public static void main(String args[])
 {
	 Scanner sc = new Scanner(System.in);
	 System.out.println("Enter 2 number");
	 int num1 = sc.nextInt();
	 int num2 = sc.nextInt(); 
	 System.out.println("Quotient of "+num1+" divided by "+num2+" is :"+(num1/num2)+"\nReminder of "+num1+" divided by "+num2+" is : "+(num1%num2)); 
	}
}

/*C:\Users\Nisha.devikar\Desktop>javac Main.java

C:\Users\Nisha.devikar\Desktop>java Main
Enter 2 number
4
3
Quotient of 4 divided by 3 is :1
Reminder of 4 divided by 3 is : 1*/