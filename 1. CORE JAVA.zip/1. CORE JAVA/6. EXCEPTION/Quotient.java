import java.util.Scanner;

class Quotient
{

public static void main(String[] args)
{
int a,b;
Scanner s= new Scanner(System.in);
System.out.println("Enter the first number");
a=s.nextInt();
System.out.println("Enter the second number");
b=s.nextInt();
try
{
  int c=a/b;
 System.out.println("The Quotient of "+a+"/"+b+" is"+c);

}
catch(Exception e)
{
System.out.println("Divide by ZeroException Caught");

}
finally
{
	System.out.println("Inside finally Block");
	
}

}

}

/*C:\Users\Nisha.devikar\Desktop>java Quotient
Enter the first number
20
Enter the second number
60
The Quotient of 20/60 is0
Inside finally Block*/