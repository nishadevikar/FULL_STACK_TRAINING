class ExceptionDemo
{
	public static void main(String[] args)
	{
		System.out.println("Yash"); //before Exception
	    System.out.println("Technologies");
		System.out.println("Nisha");
		System.out.println(100/0); //Exception in thread "main" java.lang.ArithmeticException: / by zero
        at ExceptionDemo.main(ExceptionDemo.java:8)
		System.out.println("Bye");
	}
}

/*C:\Users\Nisha.devikar\Desktop>java ExceptionDemo
Yash
Technologies
Nisha
50=100/2
Bye*/