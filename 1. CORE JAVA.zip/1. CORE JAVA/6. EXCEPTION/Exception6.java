import java.util.Scanner;
class ExamNum extends RuntimeException
{
ExamNum(String s)
{
  super(s);
}


}


class Exception6
{
public static void main(String[] args)
{int as1,as2,as3;
String as;
String ps;
int ps1,ps2,ps3;
 Scanner s= new Scanner(System.in);
 try{
 System.out.println("Enter first Student name");
  as=s.next();
  System.out.println("Enter first Subject mark");
  as1=s.nextInt();
  if(as1>100 || as1<0)
   throw new ExamNum("Number is invalid");
  System.out.println("Enter second Subject mark");
  as2=s.nextInt();
   if(as2>100 || as2<0)
   throw new ExamNum("Number is invalid");
  System.out.println("Enter third Subject mark");
  as3=s.nextInt();
   if(as3>100 || as3<0)
   throw new ExamNum("Number is invalid");
  System.out.println("Enter second Student name");
  ps=s.next();
  System.out.println("Enter first Subject mark");
  ps1=s.nextInt();
  if(ps1>100 || ps1<0)
   throw new ExamNum("Number is invalid");
  System.out.println("Enter second Subject mark");
  ps2=s.nextInt();
  if(ps2>100 || ps2<0)
   throw new ExamNum("Number is invalid");
  System.out.println("Enter third Subject mark");
  ps3=s.nextInt();
  if(ps3>100 || ps3<0)
   throw new ExamNum("Number is invalid");
  System.out.println("Average of first Student is"+((as1+as2+as3)/3));
  System.out.println("Average of Second Student is"+((ps1+ps2+ps3)/3));
 }catch(Exception e)
 {
 System.out.println(e);
 }

}


}
/*C:\Users\Nisha.devikar\Desktop>java Exception6
Enter first Student name
Nisha
Enter first Subject mark
90
Enter second Subject mark
50
Enter third Subject mark
60
Enter second Student name
40
Enter first Subject mark
60
Enter second Subject mark
66
Enter third Subject mark
55
Average of first Student is66
Average of Second Student is60*/