import java.io.*;
import java.util.Scanner;
class UnCheckedException
{
     public static void main(String args[])
	 {
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter choice for type of exception u want to see: ");
		 System.out.println("1 for ArithmeticException ");
		  System.out.println("2 for NullPointerException ");
		   System.out.println("3 for ArrayIndexOutOfBoundsException ");
		 System.out.println("4 for StringIndexOutOfBoundsException");
		 System.out.println("5 for NumberFormatException ");
		  
		 int ch=sc.nextInt();
	   int a=10,b=0,c,d;
	  UnCheckedException u=null;
	  int[] arr=new int[5];
	  String st="Yash Tech";
	   try
	   {   
	     if(ch==1) 
	      c=a/b;
	    else if(ch==2)
		  u.toString();
	    else if(ch==3)
		  System.out.println(arr[6]);
	   else if(ch==4)
		  System.out.println(st.substring(16));
	   else if(ch==5)
		  d=Integer.parseInt(sc.nextLine());
		else
			System.out.println("Successfully executed: No exception. ");
	      
	   }
	   
	   catch(ArithmeticException e)
	   {
	      System.out.println("Arithmetic Exception occurs: ");
	      
	   }
	   
	   catch(NullPointerException e)
	   {
	      System.out.println("NUll Pointer  Exception occurs: ");
	   
	   }
	   
	   catch(ArrayIndexOutOfBoundsException e)
	   {
	      System.out.println("ArrayIndexOutOfBoundsException  Exception occurs: ");
	   
	   }
	    catch(StringIndexOutOfBoundsException e)
	   {
	      System.out.println("StringIndexOutOfBoundsException  Exception occurs: ");
	   
	   }
	   
	    catch(NumberFormatException e)
	   {
	      System.out.println("NumberFormatException  Exception occurs: ");
	   
	   }
	   
	   
	   }
	   }
	   
	   
	   
	   
	   
	   
	   
	   