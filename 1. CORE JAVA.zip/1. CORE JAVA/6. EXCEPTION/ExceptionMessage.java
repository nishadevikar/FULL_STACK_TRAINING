class ExceptionMessage
{
	public static void main(String[] args)
	{
		try
		{
			int a=100,b=0,c;
			c=a/b;
			System.out.println(c);
		}
		catch(ArithmeticException e)
		{
			//e.printStackTrace();
			//System.out.println(e); // same output
			System.out.println(e.getMessage());  //by zero
		}
		finally 
		{
			System.out.println("I am in Finally Block");
		}
	}
}

/*C:\Users\Nisha.devikar\Desktop>java ExceptionMessage
java.lang.ArithmeticException: / by zero
        at ExceptionMessage.main(ExceptionMessage.java:8)*/
		
		/*C:\Users\Nisha.devikar\Desktop>java ExceptionMessage
/ by zero*/

/*C:\Users\Nisha.devikar\Desktop>java ExceptionMessage
/ by zero
I am in Finally Block*/