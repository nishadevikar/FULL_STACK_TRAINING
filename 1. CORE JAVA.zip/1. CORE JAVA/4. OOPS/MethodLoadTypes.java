//method overloading-arguments
class MethodLoadTypes
{
	void show(int a)
	{
		System.out.println("Yash");
	}
	String show(int a)
	{
		System.out.println("Technologies");
	}
	public static void main(String[] args)
	{
		    MethodLoad m1=new MethodLoad();
		    m1.show(10);
			//m1.show("nisha");
	}//ambiguity
}
	
// when (10,20) it will print only "yash" in m1.show()
//when (10) it will print only "Technologies"