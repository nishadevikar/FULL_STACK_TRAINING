import java.io.Console;
class ConsoleDemo
{
	public static void main(String[] args)
	{
		String str; char ch[];
		Console ob=System.console();
		System.out.println(" Enter Username ");
		str=ob.readline();
		System.out.println(" Enter Password ");
		ch=ob.readPassword();
		System.out.println("Username:" + str + "Password:="+ch);
	}
}
		