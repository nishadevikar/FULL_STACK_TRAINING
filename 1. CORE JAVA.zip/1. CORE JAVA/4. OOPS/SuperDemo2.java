////Super Example used to invoke immediate parent class Method
class A
{
    void display() //method
	{
	System.out.println("I am in class A-Display");
	}
}
class SuperDemo2 extends A 
{
	
	void display()
	{
		System.out.println("I am in SuperDemo2 Class");
	}
	void show()
	{
		display();
		super.display();
	}
	public static void main(String[] args)
	{
		SuperDemo2 sd=new SuperDemo2();
		sd.show();
	}
}
//C:\Users\Nisha.devikar\Desktop>javac SuperDemo2.java
//C:\Users\Nisha.devikar\Desktop>java SuperDemo2
//I am in SuperDemo2 Class
//I am in class A-Display