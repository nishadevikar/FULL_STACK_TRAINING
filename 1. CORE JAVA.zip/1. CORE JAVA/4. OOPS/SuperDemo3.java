//Super used to invoke immediate parent class constructor
class A
{
    A()
	{
	System.out.println("I am in class A-Constructor");
	}
}
class SuperDemo3 extends A 
{
	
	SuperDemo3()
	{
		//super();
		System.out.println("I am in SuperDemo3-Constructor");
	}
	public static void main(String[] args)
	{
		SuperDemo3 sd=new SuperDemo3();
		
	}
}
//C:\Users\Nisha.devikar\Desktop>javac SuperDemo3.java

//C:\Users\Nisha.devikar\Desktop>java SuperDemo3
//I am in class A-Constructor
//I am in SuperDemo3-Constructor