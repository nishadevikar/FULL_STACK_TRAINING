class new
{
	public Static void main(String[] args) 
	{
        String str="Hello";
		int len = str.length();
  
        return str.substring(1,len - 1);
    }
}
