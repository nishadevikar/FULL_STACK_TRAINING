class Box1
{
    double width;
    double height;
    double depth;
    
    /* this is the constructor for Box */
    Box1(double wid, double hei, double dep)
    {
        this.width = wid;
        this.height = hei;
        this.depth = dep;
    }
    
    /* compute and return the volume */
    double volume()
    {
         double v=width * height * depth;
         return v;
    }



    public static void main(String args[])
    {
        
        /* declare, allocate, and initialize Box objects */
        Box1 mybox1 = new Box1(100, 200, 150);
        Box1 mybox2 = new Box1(30, 60, 90);
        
        double vol;
        
        /* get the volume of the first box */
        vol = mybox1.volume();
        
        /* print the volume of the first box */
        System.out.println("Volume of the first box is " + vol);
        
        /* get the volume of the second box */
        vol = mybox2.volume();
        
        /* print the volume of the second box */
        System.out.println("Volume of the second box is " + vol);
        
    }
}