//By Method
class AnimalMethod
{
    String color; //instance variable
	int age;
	void initObject(String c,int a) //method
	{
	    color=c; //objects
		age=a;
		}
		void display()
		{
		System.out.println(color + " " +age);
		}
	public static void main(String[] args) //main method
	{
	    AnimalMethod sheru=new AnimalMethod();
		sheru.initObject("black",20); //final call
		sheru.display();
		}
}