//hierarachical 
class Animal12
{ 
    void eat()
	{
		System.out.println("eating...");
	}  
}  
class Dog extends Animal12
{ 
    void bark()
	{
		System.out.println("barking...");
	}  
}  
class Cat extends Animal12
{  
    void meow()
	{
		System.out.println("meowing...");
	}  
}  
class TestInheritance3
{  
public static void main(String args[])
{  
Cat c=new Cat();  
c.meow();  
c.eat();  
//c.bark();//C.T.Error  
}
}  
/*
C:\Users\Nisha.devikar\Desktop>java TestInheritance3
meowing...
eating...*/
