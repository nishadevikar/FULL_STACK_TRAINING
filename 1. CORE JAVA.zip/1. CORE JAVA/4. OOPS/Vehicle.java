class Vehicle
{
	void model()
	{
		System.out.println("Car is the model");
	}
}
	class Honda extends Vehicle
	{
		void colour()
		{
			System.out.println(" Black is the color");
		}
	}
	class Activa extends Honda
	{
		void speed()
		{
			System.out.println(" High Speed");
		}
	}
	class MultiLevel
	{
		public static void main(String args[])
		{
			Activa p1=new Activa();
			p1.speed();
			p1.color();
			p1.model();
		}
	}
