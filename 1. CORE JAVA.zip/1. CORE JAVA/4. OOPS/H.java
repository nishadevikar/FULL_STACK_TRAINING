//hierarchical-level
class H
{
	void displayH()
	{
		System.out.println("In H class");
	}
}
class B extends H
{
	void displayB()
	{
		System.out.println("In B class");
	}
}
class C extends H
{
	void displayC()
	{
		System.out.println("In C class");
	}
	public static void main(String[] args)
	{
		H ob1=new H();
		ob1.displayH();
		B ob2=new B();
		ob2.displayH();
		ob2.displayB();
		C ob3=new C();
		ob3.displayC();
	}
}
//C:\Users\Nisha.devikar\Desktop>java C
//In H class
//In H class
//In B class
//In C class