public class Trees {  
String color;  
Trees(String color){  
this.color = color;  
}  
void branch(String name) {  
System.out.println(name + " Tree Branches ");  
}  
void stem(String name) {  
System.out.println(name + " is of " + color + " Color");  
}  
}  
class Ashoka extends Trees{  
Ashoka(String color) {  
super(color);  
// TODO Auto-generated constructor stub  
}  
void branch(String name) {  
System.out.println(name + " Tree Branches ");  
}  
}  
  
class Main {  
public static void main(String[] args) {  
// TODO Auto-generated method stub  
Ashoka a1 = new Ashoka("green");  
Trees mango = new Trees("yellow");  
mango = a1;  
mango.stem("My tree");  
  
Trees s1 = new Trees("yellow");  
Ashoka a = (Ashoka)s1;  
}  
}  