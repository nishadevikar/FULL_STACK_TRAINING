class ThisDemo4
{
	void y1(ThisDemo4 t)
	{
		System.out.println("Y1 method");
	}
	void y2()
	{
		y1(this);
	}
	public static void main(String[] args)
	{
		ThisDemo4 t=new ThisDemo4();
		t.y2();
	}
}

/*
C:\Users\Nisha.devikar\Desktop>javac ThisDemo4.java
C:\Users\Nisha.devikar\Desktop>java ThisDemo4
Y1 method/*
//y1 and y2 are methods
