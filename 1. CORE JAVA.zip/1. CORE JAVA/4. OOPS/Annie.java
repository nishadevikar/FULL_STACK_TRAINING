class A
{
	void displayA()
	{
		System.out.println("Annie Class");
	}
}
class B extends A
{
	dispayB
	{
		System.out.println("B class");
	}
	public static void main(String[] args)
	{
		A ob1=new A();
		ob1.displayA();
		ob1.dispayB();
	}
}