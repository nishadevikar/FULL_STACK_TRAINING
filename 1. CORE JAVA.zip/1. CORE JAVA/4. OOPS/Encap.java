//Encapsulation
class Encap 
{
	private int emp_id;
	public void setEmpId(int emp_id)
	{
		this.emp_id=emp_id;
	}
	public int getEmpId()
	{
		return emp_id;
	}
}
class Organise
{
	public static void main(String[] args)
	{
		Encap e=new Encap();
		e.setEmpId(100);
		System.out.println(e.getEmpId);
	}
}
