//Multi-level Inheritance
class Vehicle12
{  
    void model()
    {
	System.out.println("Car is the model");
	}  
}  
class Honda extends Vehicle12
{  
     void color()
{
	System.out.println("Black is the color");

}
  
}  
class Activa extends Honda
{  
void speed()
{
	System.out.println("High Speed");
	}  
}  
class TestInheritance2
{  
public static void main(String args[])
{  
Activa d=new Activa();  
d.speed();  
d.color();  
d.model();  
}
} 

/*C:\Users\Nisha.devikar\Desktop>javac Vehicle12.java
C:\Users\Nisha.devikar\Desktop>java TestInheritance2
High Speed
Black is the color
Car is the model*/