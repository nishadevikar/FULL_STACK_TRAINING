class Employee
{
    int empid;
	
}
	class Organisation
{
	p.s.v.m.(String[] args)
	{
	    Employee e=new Employee;
	    e.empid=1000;
	}
}