class t1
{
	t1(ThisDemo5 td)
	{
		System.out.println("ti class constructor");
	}
}
class ThisDemo5
{
	void y1()
	{
		t1 t=new t1(this);//t1 class constructor as an argument(this)
	}
	public static void main(String[] args)
	{
		ThisDemo5 t=new ThisDemo5();
		t.y1();
		
	}
}
	/*C:\Users\Nisha.devikar\Desktop>javac ThisDemo5.java
C:\Users\Nisha.devikar\Desktop>java ThisDemo5
ti class constructor*/