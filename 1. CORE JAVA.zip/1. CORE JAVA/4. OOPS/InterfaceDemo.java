//Abstraction example by Interface method
interface A1 // code gets compiled
{
    public abstract void show(); //modifier protected not allowed
	public static final int a=20;
}
	class InterfaceDemo implements A1
{
		public void show()
	{
		System.out.println("In Demo Class");
	}
	public static void main(String[] args)
	{
		InterfaceDemo d=new InterfaceDemo();
		d.show();
	}
}
	
//C:\Users\Nisha.devikar\Desktop>javac InterfaceDemo.java
//C:\Users\Nisha.devikar\Desktop>java InterfaceDemo
//In Demo Class
		
	