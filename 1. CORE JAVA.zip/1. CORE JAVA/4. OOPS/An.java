class A
{
	void show()
	{
		System.out.println("In A class");
	}
}
class B
{
	void show()
	{
		System.out.println("In B class");
	}
}
class Cmulti extends A, B;
{
	public static void main(String[] args)
	{
		CMulti ob=new CMulti();
		ob.show();
	}
}
		