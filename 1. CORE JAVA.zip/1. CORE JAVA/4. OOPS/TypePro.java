class TypePro
{
	void show(Object a)
	{
		System.out.println("Object method");
	}
	void show(String b)
	{
		System.out.println("String Method");
	}
	public static void main(String[] args)
	{
		TypePro t=new TypePro();
		t.show('Jaynam');// int method
	}
}
//C:\Users\Nisha.devikar\Desktop>javac TypePro.java
//C:\Users\Nisha.devikar\Desktop>java TypePro
//int method