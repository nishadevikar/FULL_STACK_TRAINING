//method overloading-sequence arguments
class MethodLoadSeq
{
	void show(int a,String b)
	{
		System.out.println("Yash");
	}
	void show(String a,int b)
	{
		
        System.out.println("Technologies");
	}
	public static void main(String[] args)
	{
		MethodLoad m1=new MethodLoad();
		m1.show("Nisha",10);
	}
}
	
// when (10,20) it will print only "yash" in m1.show()
//when (10) it will print only "Technologies"