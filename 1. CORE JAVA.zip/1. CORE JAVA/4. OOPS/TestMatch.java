class TestMatch
{
	
    int a=10;//instance variable in heap area
	static int b=20;//static variable in method area
	void show()
	{
	    int c=30;//local variable in stack area
	}
	public static void main(String[] args)//main()-stack area
	{
	    Test t=new Test();//heap area
		t.show();//current running method
	}
	
}	