class MethodOverLoad1
{
	void show(String b)
	{
		System.out.println("Yash");
	}
	void show(int b)
	{
		System.out.println("Technologies");
	}
	public static void main(String[] args)
	{
		    MethodOverLoad1 m1=new MethodOverLoad1();
			m1.show(10);
	}
}

/*C:\Users\Nisha.devikar\Desktop>javac MethodOverLoad1.java
C:\Users\Nisha.devikar\Desktop>java MethodOverLoad
Technologies*/