class Trees2
{  
void shrubs()
{
System.out.println("Trees are beautiful...");
}  
}  
class plants extends Trees2
{  
void shrubs()
{System.out.println("Falling Leaves...");}  
void stems(){System.out.println("Shrubs are beautiful...");}  
void bushes(){  
super.shrubs();  
stems();  
}  
}  
class TestSuper2{  
public static void main(String args[]){  
plants d=new plants();  
d.bushes();  
}}  