//Abstraction example by Creating Abstract class method
abstract class Vehicle123 //the code gets compiled
{
	abstract void start();
	void show()
	{
		System.out.println("In Abstract class");
	}
		
}
class Car extends Vehicle123
{
	void start()
	{
		System.out.println("Starts by Key/Button");
	}
	
}
class Bike extends Vehicle123
{
	void start()
	{
		System.out.println("Starts with kick");
	}
	public static void main(String[] args)
	{
		//Vehicle123 v1=new Vehicle123(); //no implementation therefore we cannot create an object of abstract class
		Car c=new Car();
		c.start();
		Bike b=new Bike();
		b.start();
		b.show();
	}
}

//C:\Users\Nisha.devikar\Desktop>javac Vehicle123.java
//C:\Users\Nisha.devikar\Desktop>java Bike
//Starts by Key/Button
//Starts with kick
//In Abstract class