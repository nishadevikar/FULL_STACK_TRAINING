class Point2
{  
void p()
{
	System.out.println("hello p");
	}  
void n()
{  
    System.out.println("hello n");  
//m();//same as this.m()  
this.p();  
}  
}  
class TestThis4
{  
    public static void main(String args[])
	{  
Point2 a=new Point2();  
a.n();  
}
} 