//method overloading-no arguments
class MethodLoad
{
	void show(int a, int b)
	{
		System.out.println("Yash");
	}
	void show(int a)
	{
		
        System.out.println("Technologies");
	}
	public static void main(String[] args)
	{
		MethodLoad m1=new MethodLoad();
		m1.show(10);
	}
}
	
// when (10,20) it will print only "yash" in m1.show()
//when (10) it will print only "Technologies"