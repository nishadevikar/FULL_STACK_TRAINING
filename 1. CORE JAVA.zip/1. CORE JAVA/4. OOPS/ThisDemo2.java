`class ThisDemo2
{
    void display()
	{
	    System.out.println("Yash");
	}
	void show()
    {
        this.display();//this
    }
    public static void main(String[] args)
    {
        ThisDemo2 t=new ThisDemo2();
        t.show();
    }  
}
//if you don't use this keyword, compiler automatically adds this keyword while invoking the method.

/*C:\Users\Nisha.devikar\Desktop>javac ThisDemo2.java
C:\Users\Nisha.devikar\Desktop>java ThisDemo2
Yash/*