interface DairyMilkInterface
{
	void show();
}
interface Perk
{
	void display();
}
class Multi implements DairyMilkInterface,Perk
{
	public void show()
	{
		System.out.println("I like DairyMilk much more than Perk");
	}
	public void display()
	{
		System.out.println("She likes Perk more than DairyMilk");
	}
		
	public static void main(String[] args)
	{
		Multi md=new Multi();
		md.show();
		md.display();
	}
}
