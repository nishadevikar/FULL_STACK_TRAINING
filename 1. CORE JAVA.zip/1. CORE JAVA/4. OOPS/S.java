//Multiple-level inheritance
class S
{
	void displayS()
	{
		System.out.println("S Class");
	}
}
class B extends S
{
	void dispayB()
	{
		System.out.println("B class");
	}
	class C extends B
	{
	void dispayC()
	{
		System.out.println("C class");
	}
	
	public static void main(String[] args)
	{
		S ob1=new S();
		ob1.displayS();
		//ob1.dispayB();
		B ob2=new B();
		ob2.displayS();
		ob2.dispayB();
		C ob3=new C();
		ob3.dispayB();
		ob3.dispayC();
		ob3.displayS();
		
	}
}
}
