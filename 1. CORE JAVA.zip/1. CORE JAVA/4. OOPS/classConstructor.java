class A
{
    A()//constructor
	{
	}
	private void displayA()/private
	{
	}
	}
	class Bcon extends A
	{
	
	
	
	}