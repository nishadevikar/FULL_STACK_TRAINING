class Bike{
   public Bike()
   {
	System.out.println("Class Bike");
   }
   public void vehicleType()
   {
	System.out.println("Vehicle Type: Bike");
   }
}
class HeroHonda extends Bike{
   public HeroHonda()
   {
	System.out.println("Class HeroHondai");
   }
   public void brand()
   {
	System.out.println("Brand: HeroHonda");
   }
   public void speed()
   {
	System.out.println("Max: 50Kmph");
   }
}
public class Activa extends HeroHonda{

   public Activa()
   {
	System.out.println("HeroHonda Model: 800");
   }
   public void speed()
   {
	System.out.println("Max: 60Kmph");
   }
   public static void main(String args[])
   {
	 Activa obj=new Activa();
	 obj.vehicleType();
	 obj.brand();
	 obj.speed();
   }
}