class SingleInheritance
{
	String name="Nisha";
	float salary=40000;
}
class Programmer extends SingleInheritance
{
	int bonus=10000;
	public static void main(String[] args)
	{
		Programmer p1=new Programmer();
		System.out.println("Programmer salary is:" +p1.salary);
	    System.out.println("Programmer bonus is:" +p1.bonus);
	}
}
/*C:\Users\Nisha.devikar\Desktop>javac SingleInheritance.java
C:\Users\Nisha.devikar\Desktop>java Programmer
Programmer salary is:40000.0
Programmer bonus is:10000*/