//methodOverriding
class Animal1{  
  void run()
  {
  System.out.println("Animal1 is running");
  }  
}  
//Creating a child class  
class Dog extends Animal1
{  
  public static void main(String args[]){  
  //creating an instance of child class  
  Dog obj = new Dog();  
  //calling the method with child class instance  
  obj.run();  
  }  
}  