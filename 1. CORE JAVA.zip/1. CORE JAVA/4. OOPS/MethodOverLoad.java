//Method Obverloading
class MethodOverLoad
{
	void show(int a,String b)
	{
		System.out.println("Yash");
	}
	void show(String a, int b)
	{
		System.out.println("Technologies");
	}
	public static void main(String[] args)
	{
		    MethodOverLoad m1=new MethodOverLoad();
			m1.show("jaynam",10);
	}
}

//C:\Users\Nisha.devikar\Desktop>javac MethodOverLoad.java

//C:\Users\Nisha.devikar\Desktop>java MethodOverLoad
//Technologies