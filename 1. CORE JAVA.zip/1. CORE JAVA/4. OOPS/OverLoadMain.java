//can we overload a method
class OverLoadMain
{
	public static void main(String[] args)
	{
		System.out.println("Yash");
		OverLoadMain o=new OverLoadMain();
		o.main(10);
	}
	public static void main(int a)
	{
		System.out.println("Technologies");
	}
}
		//C:\Users\Nisha.devikar\Desktop>java OverLoadMain
//Yash
//Technologies

/*No, you cannot overload a method based on different return type but same argument type and number in java.In overloading it is must that the both methods have −same name.
different parameters (different type or, different number or both).*/
