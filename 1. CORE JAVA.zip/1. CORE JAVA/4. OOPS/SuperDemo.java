//Super Example used to refer immediate parent class instance variable
class A
{
int a=100;
}
class SuperDemo extends A 
{
	int a=200; //instance variable
	void display(int a)//local variable
	{
		System.out.println(a);//300
		System.out.println(this.a);//200, as this is refering to the current class instance
		System.out.println(super.a);//100, because super is being pointed to a
	}
	public static void main(String[] args)
	{
		SuperDemo sd=new SuperDemo();
		sd.display(300);// will display 300 as local variable
	}
}
//300
//200
//100