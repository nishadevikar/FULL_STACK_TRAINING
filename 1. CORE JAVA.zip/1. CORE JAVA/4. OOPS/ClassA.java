//hybrid Inheritance

public class ClassA 
{
    public void dispA()
    {
        System.out.println("disp() method of ClassA");
    }
}
public class ClassB extends ClassA 
{
    public void show()
    {
        System.out.println("show() method of ClassB");
    }
    public void dispB()
    {
        System.out.println("disp() method of ClassB");
    }
}
public class ClassC extends ClassA
{
    public void show()
    {
        System.out.println("show() method of ClassC");
    }
    public void dispC()
    {
        System.out.println("disp() method of ClassC");
    }
}
public class ClassD extends ClassB,ClassC
{
    public void dispD()
    {
        System.out.println("disp() method of ClassD");
    }
    public static void main(String args[])
    {
          ClassD d = new ClassD();
          d.dispD();
          d.show();//Confusion happens here which show method to call
    }
}