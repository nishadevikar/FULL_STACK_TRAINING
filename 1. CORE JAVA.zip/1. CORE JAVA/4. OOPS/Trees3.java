class Trees3
{  
Trees3()
{
System.out.println("Trees are beautiful");
}  
}  
class plants extends Trees3{  
plants()
{  
super();  
System.out.println("plants are green in color");  
}  
}  
class TestSuper3{  
public static void main(String args[]){  
plants p=new plants();  
}}  