class DefaultConstructor
{
	int i;
	String s;
	public DefaultConstructor()
	{
		System.out.println("Default Constructor");
	}
	public static void main(String[] args)
	{
		DefaultConstructor t=new DefaultConstructor();
		System.out.println(t.i);
		System.out.println(t.s);
	}
}

/*Default Constructor
0
null*/
		