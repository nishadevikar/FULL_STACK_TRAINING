class MethodOverLoad2
{
	void show(int a)
	{
		System.out.println("Yash");
	}
	void show(String a)
	{
		System.out.println("Technologies");
	}
	public static void main(String[] args)
	{
		    MethodOverLoad2 m1=new MethodOverLoad2();
			m1.show(10);
			m1.show("jaynam");
	}
}
/*C:\Users\Nisha.devikar\Desktop>javac MethodOverLoad2.java
C:\Users\Nisha.devikar\Desktop>java MethodOverLoad2
Yash
Technologies*/