//Abstraction example-
abstract class Chocolates //the code gets compiled
{
	abstract void eat();
	void show()
	{
		System.out.println("In Abstract class");
	}
		
}
class DairyMilk extends Chocolates
{
	void eat()
	{
		System.out.println("I am eating DairyMilk");
	}
	
}
class Munch extends Chocolates
{
	void eat()
	{
		System.out.println("I am eating Munch");
	}
	public static void main(String[] args)
	{
		//Chocolates v1=new Chocolates(); //no implementation therefore we cannot create an object of abstract class
		DairyMilk c=new DairyMilk();
		c.eat();
		Munch b=new Munch();
		b.eat();
		b.show();
	}
}

//C:\Users\Nisha.devikar\Desktop>javac DairyMilk.java

//C:\Users\Nisha.devikar\Desktop>java Munch
//I am eating DairyMilk
//I am eating Munch
//In Abstract class