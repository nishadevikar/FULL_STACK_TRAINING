class Trees1
{  
String color="Green";  
}  
class shrubs extends Trees1{  
String color="Yellow";  
void printColor(){  
System.out.println(color);//prints color of shrubs class  
System.out.println(super.color);//prints color of Trees1 class  
}  
}  
class TestSuper1
{  
public static void main(String args[])
{  
shrubs s=new shrubs();  
s.printColor();  
}}  