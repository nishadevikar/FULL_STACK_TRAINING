class ChocolatesCastException
{
	String name;
    ChocolatesCastException(String name)
	{
		this.name=name;
	}
	void eat(String taste)
	{
		System.out.println(taste + " is eating .....");  
    }  
	void show(String taste)
	{
		System.out.println(taste + " is of " + name + " Name");  
    }  
}
public class Munch extends ChocolatesCastException
{  
Munch(String name) 
{  
super(name);  
 
}
void eat(String taste) 
{  
System.out.println(taste + " is eating ....");  
}  
}      
		

public class Main {  
public static void main(String[] args) {  
 
Munch m1 = new Munch("Dark Chocolate");  
ChocolatesCastException c1 = new ChocolatesCastException("White Chocolate");  
c1 = d1;  
c1.show("My Chocolate");  
  
ChocolatesCastException a1 = new ChocolatesCastException("Cramel Toffee");  
ChocolatesCastException d = (ChocolatesCastException)a1;  
}  
}  
