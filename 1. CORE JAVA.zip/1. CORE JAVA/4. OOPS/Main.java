public class Animal1234 {  
String color;  
Animal1234(String color){  
this.color = color;  
}  
void eat(String name) {  
System.out.println(name + " is eating .....");  
}  
void show(String name) {  
System.out.println(name + " is of " + color + " Color");  
}  
}  
class Dog extends Animal1234{  
Dog(String color) {  
super(color);  
// TODO Auto-generated constructor stub  
}  
void eat(String name) {  
System.out.println(name + " is eating ....");  
}  
}  
  
public class Main {  
public static void main(String[] args) {  
// TODO Auto-generated method stub  
Dog dog = new Dog("black");  
Animal1234 animal = new Animal1234("White");  
animal = dog;  
animal.show("My dog");  
  
Animal1234 animal1 = new Animal1234("White");  
Dog d = (Dog)animal1;  
}  
}  