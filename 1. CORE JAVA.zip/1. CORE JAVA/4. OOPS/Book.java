class Author{
	private String name;
	private String email;
	private Character gender;
	
	Author(String name, String email, char gender){
		this.name = name;
		this.email = email;
		this.gender = gender;
	}
	
	Author(){
		this.name = null;
		this.email = null;
		this.gender = null;
	}
	
	String getName(){
		return this.name;
	}
	
	String getEmail(){
		return this.email;
	}
	
	Character getGender(){
		return this.gender;
	}
	
	void setName(String name){
		this.name = name;
	}
	
	void setEmail(String email){
		this.email = email;
	}
	
	void setGender(Character a){
		this.gender = a;
	}
	
	
	public String toString(){
		return "Author Name : " + this.name + ", Email: " + this.email + ", Gender: " + this.gender;
	}
}

class Book extends Author{
	private String name;
	private Author author;
	private double price;
	private int qtyInStock;
	
	Book(String name, Author author, double price, int qtyInStock){
		this.name = name;
		this.author = author;
		this.price = price;
		this.qtyInStock = qtyInStock;
	}
	
	Book(){
		this.name = null;
		this.author = null;
		this.price = 0.0;
		this.qtyInStock = 0;
	}
	
	String getBookName(){
		return this.name;
	}
	
	Author getAuthorName(){
		return this.author;
	}
	
	Double getPrice(){
		return this.price;
	}
	
	int getQtyInStock(){
		return this.qtyInStock;
	}
	
	void setName(String name){
		this.name = name;
	}
	
	void setAuthor(Author author){
		this.author = author;
	}
	
	void setPrice(double price){
		this.price = price;
	}
	
	void setQtyInStock(int qtyInStock){
		this.qtyInStock = qtyInStock;
	}
	
	public String toString(){
		return "Book Name: " + this.name + ", " + this.author.toString() + ", Price :" + this.price + ", qty: "+ this.qtyInStock;
	}
	
	public static void main(String[] args){
		Author a = new Author("Robin Sharma", "charmingchallengers@gmail.com", 'M');
		Book b = new Book();
		b.setName("The Monk Who Sold His Ferrari");
		b.setAuthor(a);
		b.setPrice(10);
		b.setQtyInStock(100);
		
		System.out.println(b.toString());
		
	}
	
}