//Multiple Interface
interface A
{
	void show();
}
interface B
{
	void display();
}
class MultiDemo implements A,B
{
	public void show()
	{
		System.out.println("In Show Method");
	}
	public void display()
	{
		System.out.println("In Display Method");
	}
		
	public static void main(String[] args)
	{
		MultiDemo md=new MultiDemo();
		md.show();
		md.display();
	}
}
/*C:\Users\Nisha.devikar\Desktop>javac MultiDemo.java
C:\Users\Nisha.devikar\Desktop>java MultiDemo
In Show Method
In Display Method*/