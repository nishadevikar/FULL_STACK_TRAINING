//Encapsulation
class Employee
{
	private int emp_id;//data hiding
	public void setEmpId(int emp_id)
	{
		this.emp_id=emp_id;
	}
	public int getEmpId()//getterSetter
	{
		return emp_id;
	}
}
class Organisation
{
	public static void main(String[] args)
	{
		Employee e=new Employee();
		e.setEmpId(1000);
		System.out.println(e.getEmpId());
	}
}
//C:\Users\Nisha.devikar\Desktop>javac Employee.java

//C:\Users\Nisha.devikar\Desktop>java Organisation
//1000