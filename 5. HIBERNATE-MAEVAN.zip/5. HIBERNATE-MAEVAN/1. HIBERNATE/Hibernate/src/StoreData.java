import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;  
import org.hibernate.SessionFactory;  
import org.hibernate.Transaction;  
import org.hibernate.boot.Metadata;  
import org.hibernate.boot.MetadataSources;  
import org.hibernate.boot.registry.StandardServiceRegistry;  
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.Query;
//import com.mysql.cj.Query;  
  
public class StoreData {  
  
    public static void main( String[] args )  
    {  
         StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
            Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
          
        SessionFactory factory = meta.getSessionFactoryBuilder().build();  
        Session session = factory.openSession();  
        Transaction t = session.beginTransaction();  
          
        /*Employee e1=new Employee();    
            e1.setId(1);    
            e1.setFirstName("Yash");    
            e1.setLastName("Technologies");    
            e1.setSalary(400000);
       session.save(e1);*/
     
       
       
       Criteria criteria = session.createCriteria(Employee.class);
		List employees = criteria.list();

		Iterator itr = employees.iterator();
		while (itr.hasNext()) {

			Employee emp = (Employee) itr.next();
			System.out.println(emp.getId());//for fetching the data
			System.out.println(emp.getFirstName());
			System.out.println(emp.getLastName());
		}
		
		
		
        Query query=session.createQuery("delete from Employee where id=1");  
//specifying class name (Emp) not tablename  
query.executeUpdate();  //For deleting the data from the table
       t.commit();  
System.out.println("successfully deleted");
      // System.out.println("successfully saved");  
    
        factory.close();  
        session.close();     
    }  
}  