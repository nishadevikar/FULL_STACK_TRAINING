import React,{Component} from 'react';

class Bigimage extends React.Component

{

    render()

    {

        return(<div>

            <h1>YASH TECHNOLOGIES</h1>
            <img src="yash1.jpg" width="750" height="200"></img>

        </div>);

    }

}

export default Bigimage;