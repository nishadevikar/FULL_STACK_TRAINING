import React, {Component} from 'react';

class Content2 extends React.Component

{

render()

{

    return(

        <div>

            <h2>LOGIN PAGE</h2>
            <head>
                
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" />  
</head>  


   
              <lSabel for="username"> Enter your Name / Email </lSabel>  
             <input type="text" class="form-control text-lowercase" id="username" required="" name="username" value="" />  
             
    <label class="d-flex flex-row align-items-center" for="password"> Enter your Password   
     <a class="ml-auto border-link small-xl" href="#"> Forget Password? </a> </label>  
<input type="password" class="form-control" required="" id="password" name="password" value="" />  
     
            <input type="checkbox" class="custom-control-input" id="remember-me" name="remember-me" data-parsley-multiple="remember-me" />  
   <label clss="custom-control-label" for="remember-me"> Remember me? </label>  
                 
         <div class="form-group pt-1">  
      <button class="btn btn-primary btn-block" type="submit"> Log In </button>   
            
       <span class="text-muted"> Not a member? </span>  
        <a href="#"> Sign up </a>  
 

        </div>
        </div>

    );

}



}

export default Content2;