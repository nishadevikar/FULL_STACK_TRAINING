import React, {Component} from 'react';

class Content1 extends React.Component

{

render()

{

    return(

        <div>

            <h1>Content box 1</h1>
            <p>Starbucks is a global cafe-bakery chain that began operating in 1971 and currently has over 24,000 locations.
                
                Starbucks menu includes a wide variety of Coffee blended and Espresso blended beverages
                like Caramel Macchiato, Cold Brew, White Chocolate Mocha and much more.
              
                </p>

        </div>

    );

}



}

export default Content1;