import React, {Component} from 'react';



class Content2 extends React.Component

{

render()

{

    return(

        <div>

            <h1>Content box 2</h1>
            <p>
             Visit Starbucks to know more.
             
            </p>

        </div>

    );

}



}

export default Content2;