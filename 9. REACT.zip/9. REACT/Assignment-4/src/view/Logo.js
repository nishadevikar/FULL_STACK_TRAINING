import React, {Component} from 'react';

class Logo extends React.Component

{

render()

{

    return(

        <div>

            <h1>Logo</h1>
            <center>
            <img src="logo.png" width="80" height="80"></img>
            </center>
        </div>

    );

}



}

export default Logo;