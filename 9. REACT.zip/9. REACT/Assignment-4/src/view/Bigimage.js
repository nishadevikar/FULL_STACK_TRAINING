import React,{Component} from 'react';

class Bigimage extends React.Component

{

    render()

    {

        return(<div>

            <h1>Big image</h1>
            <img src="star.jpg" width="500" height="200"></img>

        </div>);

    }

}

export default Bigimage;