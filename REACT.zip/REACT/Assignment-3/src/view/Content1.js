import React, {Component} from 'react';

class Content1 extends React.Component

{

render()

{

    return(

        <div>

            <h2>REGISTRATION PAGE</h2>
            
               <fieldset>
                <form>
                
                <label> Firstname: </label>
                <input type="text" name="firstname" size="15"/>
                <br></br>
                <label> Middlename: </label>
                <input type="text" name="middlename" size="15"/> 
                <br></br> 
                <label> Lastname: </label>
                <input type="text" name="lastname" size="15"/>
                <br></br>
                <label> Password: </label>
                <input type="password"  id="pass" required="true" minlength="8"/>
                <br></br>
                <label>Confirm Password: </label>
                <input type="password" id="con_pass" required="true" minlength="8"/>
                <br></br>
    

            <label> Email Id: </label>

            <input type="text" name="email" size="15"/>
            <br></br>

            <label> Landline No: </label>

            <input type="text" name="landline" size="15"/>
            <br></br>
            <label> Address: </label>

            <input type="text" name="address" size="15"/>
            <br></br>
            <label>Upload Profile Picture:</label>
           <input type="file" name="myImage" accept="image/x-png,image/gif,image/jpeg" />
           <br></br>
             <label>Age:</label>  
        <input type="text" id="age" required="true"/>
        <br></br>

            <label> BaseLocation: </label>
            <select>
                <option value="pune">Pune</option>
                <option value="indore">Indore</option>
                <option value="mumbai">Mumbai</option>
                <option value="hyderabad">Hyderabad</option>
                </select>
                <br></br>
                <label> Documentation Proof: </label>
                <select>
                    <option value="Pan-card">PAN</option>
                    <option value="adhaar">ADHAAR</option>
                    </select>
                   
                    <br></br>
    
            <input type="submit" value="submit"/>
            

                </form>
               </fieldset>
            

        </div>

    );

}



}

export default Content1;