package Trainee;
public class irm
{
	 
	public void display()
	{
	String name = "Snehal Pawar";
	 String designation = "Senior Technical Trainer";
	 String baseunit = "BG5-BU14";
	 String email = "snehal.pawar@yash.com";
	 String location = "Pune";
		System.out.println("Details Of IRM:");
		
		System.out.println("Employee_name = " + name);
	    System.out.println("Employee_Designation = " +designation);
	    System.out.println("BaseUnit = " + baseunit);
        System.out.println("YASH_email = " + email);
	    System.out.println("BaseLocation = " + location);
	}
}
