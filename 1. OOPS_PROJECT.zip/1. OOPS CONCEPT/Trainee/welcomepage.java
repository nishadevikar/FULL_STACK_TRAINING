package Trainee;
public class welcomepage
{
	public void display()
	{
		System.out.println("Welcome To YASH Technologies Trainee Management System");
	}
}
