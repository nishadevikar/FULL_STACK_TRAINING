import java.util.Scanner;  //Scanner to take input from the keyboard
import Trainee.welcomepage; //welcome page of the YASH Technologies Trainee Management System
import Trainee.technicaltrainer; //Technical Trainer 
import Trainee.irm; //IRM 
import Trainee.hr; //HR


class AssociateTrainee //main class
{
	private String name;   //private data hidden- Encapsulation
	private String email;
	private Character gender;
	
	//getter, setter methods to get and set the values of name, email and gender of the candidate.
	
	AssociateTrainee(String name, String email, char gender) //parameterised constructor
	{
		this.name = name;
		this.email = email;
		this.gender = gender;
	}
	
	AssociateTrainee()
	{
		this.name = null;
		this.email = null;
		this.gender = null;
	}
	
	String getName()
	{
		return this.name;
	}
	
	String getEmail()
	{
		return this.email;
	}
	
	Character getGender()
	{
		return this.gender;
	}
	
	void setName(String name)
	{
		this.name = name;
	}
	
	void setEmail(String email)
	{
		this.email = email;
	}
	
	void setGender(Character a)
	{
		this.gender = a;
	}
	
	public String toString() //override method toString function to return the values.
	{
		return "Designation name : " + this.name + ", Email: " + this.email + ", Gender: " + this.gender;
	}
}


//Inheritance Example- inheriting properties of parent class AssociateTrainee to child class Candidate

class Candidate extends AssociateTrainee
{
	private String name;
	private AssociateTrainee associate;
	private int emp_id;
	
	
	Candidate(String name, AssociateTrainee associate, int emp_id)
	{
		this.name = name;
		this.associate = associate;
		this.emp_id = emp_id;
	}
	
	Candidate()
	{
		this.name = null;
		this.associate = null;
		this.emp_id = 0;
	}
	
	String getCandidateName()
	{
		return this.name;
	}
	
	AssociateTrainee getAssociateTraineeName()
	{
		return this.associate;
	}
	
	int getEmp_Id()
	{
		return this.emp_id;
	}
	
	
	
	void setName(String name)
	{
		this.name = name;
	}
	
	void setAssociateTrainee(AssociateTrainee associate)
	{
		this.associate = associate;
	}
	
	void setEmp_Id(int emp_id)
	{
		this.emp_id = emp_id;
	}
	
	//override methods toString function
	public String toString()
	{
		return "Candidate Name: " + this.name + ", " + this.associate.toString() + ", Emp_Id :" + this.emp_id;
	}
	
	public static void main(String[] args) //main method

	{
		AssociateTrainee a = new AssociateTrainee("Associate Trainee", "nisha.devikar@yash.com", 'F');
		Candidate b = new Candidate();
		b.setName("NISHA DEVIKAR");
		b.setAssociateTrainee(a);
		b.setEmp_Id(1014794);
		
		System.out.println(b.toString());
		
	
    
	// creates an object of Scanner to take the input from the keyboard
	System.out.println("1.hr");
	System.out.println("2.technicaltrainer");
	System.out.println("3.irm");
	Scanner input = new Scanner(System.in);

    System.out.println("Enter your choice: ");
	String c = input.nextLine();
	 System.out.println("My choice is: " + c);
	 input.close();
	
	    
		welcomepage ob=new welcomepage();		//welcomepage to display title of project
		technicaltrainer ob1=new technicaltrainer();  //technicaltrainer records
		irm ob2=new irm();   //IRM details
		hr ob3=new hr();   //Human Resource executive
		
		
		ob.display();  //object call from the welcomepage
		
		//use of if else if condition
		if(c.equals("1"))   
		{
			ob3.display();  //object call from HR
		}
		else if(c.equals("3"))
		{
			ob2.display();   //object call from IRM
		}
		else if(c.equals("2"))
		{
			ob1.display();    //object call from TechnicalTrainer
		}
		else
		{
			System.out.println("OOP'S not existing");  //if any other irrelevant input is given
		}
		
		
	}
		
}



		

  
  
	