setTimeout(fun1,2000);

function fun1()
{
 console.log("hello after 5 seconds");
}
for(let i=1;i<=100;i++)
 console.log(i);