var x=(a,b)=> a+b;
console.log("sum " +x(10,22));

var msg=()=>{ console.log("hello everyone");}
msg();
var si=(p,r,t)=> {
    return (p*r*t)/100;
}
console.log(si(1000,5,5));

//single paramter in arrow func.

var u= m=>" value you passed "+m;
console.log(u(1234));
console.log(u("nisha devikar"));

const myfunc = (x)=>x*x;
console.log(myfunc(10));