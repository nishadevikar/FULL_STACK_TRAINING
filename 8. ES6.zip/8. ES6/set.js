const names = new Set( [ "nisha","nimita","maneesh"]);
console.log(names.size);
names.add("viki");
console.log(names.size);
for(let x of names.values())
console.log(x);

names.delete("viki");
console.log("after deletion");
for(let x of names.values())
console.log(x);

names.forEach(function(v) {
    console.log(v);
});
