var array1 =[3,6,9];
var array2 = [2,4,8];
var combarray = [...array1,...array2];
console.log(combarray);

var array3 = [2,4,6,7,8,911,123,98];

var [f,s,t,...rem]=array3;
console.log(f);
console.log(s);
console.log(t);
console.log(rem);