function show()
{
    console.log("show func. called");
}
show();
var x=function(a,b)
{
    console.log(a+b);
}
x(12,22);