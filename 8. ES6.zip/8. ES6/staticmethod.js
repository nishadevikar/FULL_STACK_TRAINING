class s1
{
    static show()
    {
        console.log("this is static");
    }
}
    s1.show();
