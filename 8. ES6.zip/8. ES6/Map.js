const marksStu = new Map([["anil",67],["sunil",87]]);
console.log(marksStu.get("anil"));
marksStu.set("sanjay",77);
marksStu.set("nisha",87);
marksStu.set("priti",97);

marksStu.forEach(function(value,key) {
    console.log("key:-"+key +" value:- "+value);
});

marksStu.delete("anil");
marksStu.forEach(function(value,key) {
console.log("key:-"+key +" value:- "+value)});

if(marksStu.has("anil"))
console.log("anil exists");
else
console.log("anil doesn't exist");
for(let t of marksStu.entries())
{
    //when we fetch values using entries func. it return array of key and value, key
    //is at 0 index and value is at 1 index.
    console.log(t[0]+t[1]);
}