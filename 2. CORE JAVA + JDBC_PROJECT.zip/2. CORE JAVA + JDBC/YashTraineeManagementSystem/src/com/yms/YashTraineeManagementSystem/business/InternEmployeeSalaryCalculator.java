package com.yms.YashTraineeManagementSystem.business;

import com.yms.YashTraineeManagementSystem.dto.YashEmployee;

public class InternEmployeeSalaryCalculator extends SalaryCalculator {

	public void calculateNetSalary(YashEmployee e, int actualSalary) {
		int grossSalary = getGrossSalary(e, actualSalary);
		int tds = 2000;
		int netSalary = grossSalary - tds;
		
		System.out.println("Intern YashEmployee Salary Details");
		System.out.println("Empid = "+ e.getEmpid());
		System.out.println("Empname = "+ e.getEmpname());
		System.out.println("Designation = "+ e.getDesignation());
		System.out.println("Gross Salary = "+ grossSalary);
		System.out.println("Net Salary = "+ netSalary);
		System.out.println("Deductions = " + tds);
		
		
	}

}

		
	


