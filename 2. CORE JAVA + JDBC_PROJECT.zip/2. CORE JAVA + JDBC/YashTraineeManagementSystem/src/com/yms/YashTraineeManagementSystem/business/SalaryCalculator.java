package com.yms.YashTraineeManagementSystem.business;

import com.yms.YashTraineeManagementSystem.dto.YashEmployee;

public abstract class SalaryCalculator {
	public int getGrossSalary(YashEmployee e, int actualSalary) {
		int grossSalary = 0;
		int perDaySalary = actualSalary/30;
		grossSalary = perDaySalary * e.getDayattende();
		return grossSalary;
		
	}
	public abstract void calculateNetSalary(YashEmployee e, int actualSalary);
}
		

