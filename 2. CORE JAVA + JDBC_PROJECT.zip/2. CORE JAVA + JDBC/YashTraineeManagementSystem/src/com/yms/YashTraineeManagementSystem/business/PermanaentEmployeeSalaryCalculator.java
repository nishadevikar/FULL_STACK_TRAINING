package com.yms.YashTraineeManagementSystem.business;

import com.yms.YashTraineeManagementSystem.dto.YashEmployee;

public class PermanaentEmployeeSalaryCalculator extends SalaryCalculator {
	
	public void calculateNetSalary(YashEmployee e,int actualSalary) {
		int grossSalary = getGrossSalary(e, actualSalary);
		int incomeTax = 1000;
		int pf=800;
		int gratuity = 100;
		int netSalary = grossSalary - (incomeTax + pf + gratuity);
		
		System.out.println("Permanent YashEmployee Salary Details");
		System.out.println("Empid = "+ e.getEmpid());
		System.out.println("Empname = "+ e.getEmpname());
		System.out.println("Designation = "+ e.getDesignation());
		System.out.println("Gross Salary = "+ grossSalary);
		System.out.println("Net Salary = "+ netSalary);
		System.out.println("Deductions = " + (pf + incomeTax + gratuity));
		
		
	}

}
