package com.yms.YashTraineeManagementSystem.service;

import java.util.List;

import com.yms.YashTraineeManagementSystem.dao.YashEmployeeDAOYtmsImpl;
import com.yms.YashTraineeManagementSystem.dao.IYashEmployeeDAO;
import com.yms.YashTraineeManagementSystem.dto.YashEmployee;
import com.yms.YashTraineeManagementSystem.exceptions.YashEmployeeNotFoundException;

public class YashEmployeeServiceImpl implements IYashEmployeeService{

	private IYashEmployeeDAO empDao = new YashEmployeeDAOYtmsImpl();
	@Override
	public void addYashEmployee(YashEmployee e) {
		empDao.addYashEmployee(e);
		
	}

	@Override
	public void deleteYashEmployee(int empid) {
		empDao.deleteYashEmployee(empid);
		
	}

	@Override
	public void updateYashEmployee(YashEmployee e) {
		//empDao.updateYashEmployee(e);
		
	}

	@Override
	public YashEmployee findYashEmployee(YashEmployee e) throws YashEmployeeNotFoundException {
		// TODO Auto-generated method stub
		return empDao.findYashEmployee(e);
	}

	@Override
	public List<YashEmployee> showAllYashEmployees() {
		// TODO Auto-generated method stub
		return empDao.showAllYashEmployees();
	}
	

}
