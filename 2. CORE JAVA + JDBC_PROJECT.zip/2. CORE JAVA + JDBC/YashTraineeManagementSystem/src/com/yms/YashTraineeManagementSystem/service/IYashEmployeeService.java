package com.yms.YashTraineeManagementSystem.service;

import java.util.List;

import com.yms.YashTraineeManagementSystem.dto.YashEmployee;
import com.yms.YashTraineeManagementSystem.exceptions.YashEmployeeNotFoundException;

public interface IYashEmployeeService {
	public abstract void addYashEmployee(YashEmployee e);
	public abstract void deleteYashEmployee(int empid);
	public abstract void updateYashEmployee(YashEmployee e);
	public abstract YashEmployee findYashEmployee(YashEmployee e) throws YashEmployeeNotFoundException;
	public List<YashEmployee> showAllYashEmployees();
}
