package com.yms.YashTraineeManagementSystem.main;
import com.yms.YashTraineeManagementSystem.business.PermanaentEmployeeSalaryCalculator;
import com.yms.YashTraineeManagementSystem.business.InternEmployeeSalaryCalculator;
import com.yms.YashTraineeManagementSystem.dto.YashEmployee;


public class YashEmployeeSalaryMain {
	public static void main(String[] args) {
		PermanaentEmployeeSalaryCalculator pe =new PermanaentEmployeeSalaryCalculator();
		pe.calculateNetSalary(new YashEmployee(1234,"Arjun", "Senior Manager", 29),300000 );
		
		System.out.println("********************************");
		InternEmployeeSalaryCalculator ie = new InternEmployeeSalaryCalculator();
		ie.calculateNetSalary(new YashEmployee(8769,"Nisha", "Associate Trainee", 29),30000 );
		
	}

}
