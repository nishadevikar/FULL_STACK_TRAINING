package com.yms.YashTraineeManagementSystem.main;

import java.util.LinkedList;

import java.util.List;

import com.yms.YashTraineeManagementSystem.dto.YashEmployee;
import com.yms.YashTraineeManagementSystem.exceptions.YashEmployeeNotFoundException;
import com.yms.YashTraineeManagementSystem.service.IYashEmployeeService;
import com.yms.YashTraineeManagementSystem.service.YashEmployeeServiceImpl;



public class YashEmployeeMain {
	public static void main(String[] args)
	{
		
		
		IYashEmployeeService eservice = new YashEmployeeServiceImpl();
		eservice.addYashEmployee(new YashEmployee(1111, "Nisha", "Associate Trainee", 30));
		eservice.addYashEmployee(new YashEmployee(2222, "Divya", "Trainee Programmer", 29));
		eservice.addYashEmployee(new YashEmployee(3333, "Payal", "Associate Trainee", 28));
		eservice.addYashEmployee(new YashEmployee(4444, "Rupali", "Associate Trainee", 29));
		
		System.out.println("  ");
		
		List<YashEmployee> elist = eservice.showAllYashEmployees();
		for(YashEmployee e : elist) {
			System.out.println(e.getEmpid()+":"+e.getEmpname()+":"+e.getDesignation()+":"+e.getDayattende());
			
		}
		System.out.println("  ");
		
		eservice.deleteYashEmployee(1111);
		//eservice.updateYashEmployee(new YashEmployee(2222,"updated","Senior Trainee Programmer",28));
		try {
			YashEmployee temp = eservice.findYashEmployee(new YashEmployee(2222,"updated","Sr.Trainee Programmer",28));
			System.out.println(temp.getEmpid()+" "+temp.getEmpname());
		} catch (YashEmployeeNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
			
		
	}

}
