package com.yms.YashTraineeManagementSystem.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.yms.YashTraineeManagementSystem.HigherEmployee.HiringExecutive;
import com.yms.YashTraineeManagementSystem.HigherEmployee.TechnicalTrainer;

public class YashEmployeeHigherMain {
	public static void main(String[] args) {
		HiringExecutive  h1 =new HiringExecutive ();
		TechnicalTrainer t1 = new TechnicalTrainer();
		h1.display();
		t1.display();
		
		try
		{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			//create connection
			String url="jdbc:mysql://localhost:3306/ytms";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
				System.out.println("Connection is created Successfully");
			}
			else
			{
				System.out.println("Connection is created Successfully");
			} //step 3 : create the query
			String q="select * from hr";
			
			String q1="select * from tt";
			
			Statement st=con.createStatement();
			ResultSet set=st.executeQuery(q);
			Statement st1=con.createStatement();
			ResultSet set1=st1.executeQuery(q1);
			//step 4: process the data
			while(set1.next())
			{
				String name=set1.getString("empName");
				System.out.println("empName:" +name);
				String designation=set1.getString("empDesignation");
				System.out.println("empDesignation:" +designation);
				String emailid=set1.getString("empEmailID");
				System.out.println("empEmailID:" +emailid);
				String BaseLocation=set1.getString("empbaselocation");
				System.out.println("empBaseLocation:" +BaseLocation);
				

			}
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
	    }
	}
}
		

