package com.yms.YashTraineeManagementSystem.exceptions;

public class YashEmployeeNotFoundException extends Exception {
private int empid;
	public YashEmployeeNotFoundException(int empid) {
		this.empid = empid;
	}
	
	public String toString() {
		return "Employee Not Found Exception " + this.empid;
	}

}
