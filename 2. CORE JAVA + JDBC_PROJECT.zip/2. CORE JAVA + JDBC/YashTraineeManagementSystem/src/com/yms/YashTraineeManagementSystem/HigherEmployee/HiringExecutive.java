package com.yms.YashTraineeManagementSystem.HigherEmployee;
import java.util.*;
class HR
{
	String name;
	String designation;
	String emailid;
	String baseunit;
	
	public HR(String name, String designation, String emailid, String baseunit)
	{
		this.name = name;
		this.designation = designation;
		this.emailid = emailid;
		this.baseunit = baseunit;
	}
}

public class HiringExecutive {
	{
		
		{
			List<HR> list = new LinkedList<HR>();
			HR h1 = new HR("Name of HR : Tanay Pratap Singh", "Designation : HR", "Yash emailid : tanay.singh@yash.com", "BaseLocation : Indore");
			list.add(h1);
			for(HR h:list)
			{
				System.out.println(h.name+"\n "+h.designation+"\n "+h.emailid+"\n"+h.baseunit);
			}
		}
	}

	public void display() {
		// TODO Auto-generated method stub
		
	}
	

}
