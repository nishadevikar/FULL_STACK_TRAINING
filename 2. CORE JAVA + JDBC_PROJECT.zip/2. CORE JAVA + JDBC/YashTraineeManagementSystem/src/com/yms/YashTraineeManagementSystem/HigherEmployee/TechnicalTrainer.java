package com.yms.YashTraineeManagementSystem.HigherEmployee;

import java.util.LinkedList;
import java.util.List;
class TT
{
	String name;
	String designation;
	String emailid;
	String baseunit;
	
	public TT(String name, String designation, String emailid, String baseunit)
	{
		this.name = name;
		this.designation = designation;
		this.emailid = emailid;
		this.baseunit = baseunit;
	}
}

public class TechnicalTrainer {
	{
		List<TT> list = new LinkedList<TT>();
		TT h1 = new TT("Name of TT : Jaynam Sanghavi", "Designation : Technical Trainer", "Yash emailid : jaynam.sanghvi@yash.com", "BaseLocation : Indore");
		list.add(h1);
		for(TT h:list)
		{
			System.out.println(h.name+"\n "+h.designation+"\n "+h.emailid+"\n"+h.baseunit);
		}
	}


public void display() {
	// TODO Auto-generated method stub
	
}


}




		


