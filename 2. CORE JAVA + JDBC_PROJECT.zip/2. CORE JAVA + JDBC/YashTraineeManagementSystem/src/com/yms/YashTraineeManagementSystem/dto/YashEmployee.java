package com.yms.YashTraineeManagementSystem.dto;

public class YashEmployee {
	private int empid;
	private String empname;
	private String designation;
	private int dayattende;
	public YashEmployee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public YashEmployee(int empid, String empname, String designation, int dayattende) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.designation = designation;
		this.dayattende = dayattende;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public int getDayattende() {
		return dayattende;
	}
	public void setDayattende(int dayattende) {
		this.dayattende = dayattende;
	}
	
	
	

}
