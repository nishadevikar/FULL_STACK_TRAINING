package com.yms.YashTraineeManagementSystem.dao;

import java.util.List;

import com.yms.YashTraineeManagementSystem.dto.YashEmployee;
import com.yms.YashTraineeManagementSystem.exceptions.YashEmployeeNotFoundException;

public interface IYashEmployeeDAO {
	public abstract void addYashEmployee(YashEmployee e);
	public abstract void deleteYashEmployee(int empid);
	public abstract void updateYashEmployee(YashEmployee e);
	public abstract YashEmployee findYashEmployee(YashEmployee e) throws YashEmployeeNotFoundException;
	public List<YashEmployee> showAllYashEmployees();
	public static final String url="jdbc:mysql://localhost:3306/ytms";
	public static final String User="root";
	public static final String Pass="root";
	public static final String Driver_Classname="com.mysql.jdbc.Driver";
	
		
	}


